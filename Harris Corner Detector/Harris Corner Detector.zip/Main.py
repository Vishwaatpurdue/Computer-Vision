"""
Author: Vishveswaran Jothi
Main Program for Harris Corner and Sift Detector 
"""
import cv2
from harris import *
#########################################
# Obtaining input from the user
#########################################
path = "Enter the full path for the images:"
img_name = "Enter the image name with file type/ file extension:"
sigma_prompt = "Enter the sigma (Kernel size):"
levels_prompt = "Enter the no. of levels in which harris corner needs to be detected:"
K_prompt="Enter the value of K (0.04~0.06)"
T_ncc_prompt="Enter the value of threshold for NCC metrics (0.6~0.9)"
T_max_global_prompt="Enter the value of threshold for finding keypoint among global maximums \n Lower the value to get more keypoints... (0.2~0.8)  "
T_ssd_prompt="Enter the value of threshold for SSD metrics (0.7~0.9)"
T_min_global_prompt="Enter the value of threshold for finding keypoint among global minimums \n Increase the value to get more keypoints... (3~7)  "

file_path=raw_input(">"+path)
img_name1=raw_input(">"+img_name)
img_name2=raw_input(">"+img_name)
sigma=float(raw_input(">"+sigma_prompt))
no_levels=raw_input(">"+levels_prompt)
K=int(raw_input(">"+K_prompt))
T_ncc=int(raw_input(">"+T_ncc_prompt))
T_max_global=int(raw_input(">"+T_max_global_prompt))
T_ssd=int(raw_input(">"+T_ssd_prompt))
T_min_global=int(raw_input(">"+T_min_global_prompt))
img_1=cv2.imread(path+"/"+img_name1)
img_2=cv2.imread(path+"/"+img_name2)
"""
#########################################
# Obtaining input code ends here
#########################################

#########################################
# Sample input code for referrence
img_1=cv2.imread("/home/vishwa/661/Hw4/HW4Pics/pair4/1.jpg")
img_2=cv2.imread("/home/vishwa/661/Hw4/HW4Pics/pair4/2.jpg")
no_levels=2
sigma=1.1
W_size=25
W_nms=29
K=0.04
T_ncc=0.8
T_max_global=0.4
T_ssd=0.8
T_min_global=5
print "Harris corner for " + str(no_levels) + "th levels are computed here"
#######################################
"""

#########################################
# Converting the images to gray scale
img_1gray=cv2.cvtColor(img_1,cv2.COLOR_BGR2GRAY)
img_2gray=cv2.cvtColor(img_2,cv2.COLOR_BGR2GRAY)
#########################################

#########################################
# Obtaining Corner points for Image 1
Corner_1 = harris_corner_detector(img_1gray,sigma,no_levels,K,W_nms)
# Obtaining Corner points for Image 2
Corner_2 = harris_corner_detector(img_2gray,sigma,no_levels,K,W_nms)
#########################################

#########################################
# Obtaining matches between two images using NCC metrics
Coord1 = NCC_images(Corner_1,Corner_2,img_1gray,img_2gray,W_size,T_ncc,T_max_global)
Map1 = plotting(Coord1,img_1,img_2)
cv2.imwrite("output/Pair4_NCC_lvl2_0_9_sig_1_1.jpg",Map1)
#########################################

#########################################
# Obtaining matches between two images using SSD metrics
Coord2 = SSD_images(Corner_1,Corner_2,img_1gray,img_2gray,W_size,T_ssd,T_min_global)
Map2 = plotting(Coord2,img_1,img_2)
cv2.imwrite("output/Pair4_SSD_lvl2_0_8_sig_1_1.jpg",Map2)
#########################################

"""
Pair-2
sigma=1.1
W_size=25
W_nms=29
K=0.04
T_ncc=0.6
T_max_global=0.5
T_ssd=0.83
T_min_global=5

Pair-1
sigma=1.1
W_size=25
W_nms=29
K=0.04
T_ncc=0.7
T_max_global=0.5
T_ssd=0.68
T_min_global=5

Pair-3
sigma=1.1
W_size=25
W_nms=29
K=0.04
T_ncc=0.5
T_max_global=0.5
T_ssd=0.46
T_min_global=5

pair-4
"""
