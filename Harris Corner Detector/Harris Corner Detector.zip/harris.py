"""
author: Vishveswaran Jothi
"""

import cv2
import numpy as np
import math as M
from scipy import ndimage

#########################################
# Harris corner detector code starts here
#########################################
def harris_corner_detector(img_org,sigma,level,K,W_nms):
	""" Code for harris corner detection 
	"""
	
	# In this step we obtain the window size to the even no next to the 4*sigma 
        Window_size=int(M.ceil(round(4*level*sigma,0)/2)*2)
	# smooth the image using gaussian filter to get better results
	img=cv2.GaussianBlur(img_org,(Window_size-1,Window_size-1),0)
	#img=img_org
	# Creating Haar Filters in accordance to the kernel size
        Haar_X=np.concatenate((-np.ones((Window_size,Window_size/2),dtype=np.int), np.ones((Window_size,Window_size/2),dtype=np.int)),axis=1)
        Haar_Y=np.concatenate((np.ones((Window_size/2,Window_size),dtype=np.int), -np.ones((Window_size/2,Window_size),dtype=np.int)),axis=0)
        # Applying Haar filters to the image
	Ix=cv2.filter2D(img,-1,Haar_X)
	Iy=cv2.filter2D(img,-1,Haar_Y)
	#Ix= ndimage.convolve(img,Haar_X,mode='constant')
	#Iy= ndimage.convolve(img,Haar_Y,mode='constant')
	height=img.shape[0]
	width=img.shape[1]
	# creating a new window size which is nearest even integer of 5*sigma
	new_Window= int(M.ceil(M.ceil(5*level*sigma)/2)*2)+1
	new_half_W= int(M.ceil(new_Window/2))
	Corner_res=np.zeros((img.shape),dtype='float')
	# Obtain the Corner response matrix
	for i in range(new_half_W,height-new_half_W+1):
	  for j in range(new_half_W,width-new_half_W+1):
             Ix_ij=Ix[i-new_half_W:i+int(M.floor(new_Window/2)),j-new_half_W:j+int(M.floor(new_Window/2))]
             Iy_ij=Iy[i-new_half_W:i+int(M.floor(new_Window/2)),j-new_half_W:j+int(M.floor(new_Window/2))]
             Mat=np.zeros((2,2),dtype='float')
             Mat[0,0]=np.sum(np.square(Ix_ij))
             Mat[1,1]=np.sum(np.square(Iy_ij))
             Mat[0,1]=np.sum(np.multiply(Ix_ij,Iy_ij))
	     Det_Mat=Mat[0,0]*Mat[1,1]-2*Mat[0,1]
             tr_Mat=Mat[0,0]+Mat[1,1]
	     Corner_res[i,j]=Det_Mat-K*(tr_Mat**2)
	
	# For non maximal supression to remove multiple corners nearby we use the following code
     	# Also we discard the values with low corner response by thresholding it to 50% of maximum value of the corner response
	
	corner_coord=[]
	
     	for i in range(W_nms/2,height-W_nms/2+1):
         for j in range(W_nms/2,width-W_nms/2+1):
		Corner_res_sub=Corner_res[i-W_nms/2:i+W_nms/2+1,j-W_nms/2:j+W_nms/2+1]
		if Corner_res[i,j]==np.max(Corner_res_sub) and Corner_res[i,j]> 0.1*np.max(Corner_res):
			corner_coord.append([i,j])
	#return the corner coordinates as array
	return np.asarray(corner_coord)
#########################################
# Code for harris corner detection ends here
#########################################
 
#########################################
# Plotting function starts here
def plotting(Corner_Coord,img1,img2):
	# creating a base image which has image 1 and image 2
    	img=np.zeros((max(img1.shape[0],img2.shape[0]),img1.shape[1]+img2.shape[1],3))
    	img[:img1.shape[0], :img1.shape[1]]=img1
    	img[:img2.shape[0], img1.shape[1]:img1.shape[1]+img2.shape[1]]=img2
	output=img
	# plotting the keypoints and the correspondence between images using circles and lines
	for coord in Corner_Coord:
		output=cv2.circle(output,(coord[1],coord[0]),2,(120,53,188),2)
		output=cv2.circle(output,(img1.shape[1]+coord[3],coord[2]),2,(120,53,188),2)
		output=cv2.line(output,(coord[1],coord[0]),(img1.shape[1]+coord[3],coord[2]), (255,0,55))
	return output
# Plotting function ends here
#########################################
 
#########################################
# Plotting keypoints function starts here
def plotting_keypoints(Corner_Coord,img1):
	# creating a base image which has image 1 and image 2
    	output=img1
	# plotting the keypoints
	for coord in Corner_Coord:
		cv2.circle(output,(coord[1],coord[0]),5,(120,53,188),2)
		
	return output
# Plotting keypoints function ends here
#########################################
 
#########################################
# Function to find the Sum of Least squares for each level starts here
def SSD_images(Corner_Coord1,Corner_Coord2,img_1,img_2,W_size,T_ssd,T_min_global):
        """ Code for SSD to correlate between two views of the same image
        """
	# Creating the window size for find the descriptors for the corner	
	W_half=int(W_size/2)
	src=Corner_Coord1
	dest=Corner_Coord2
	src_img=img_1
	dest_img=img_2
	ssd_mat=np.zeros((len(src),len(dest)),dtype='float')
	# Calculating SSD for all points
	for loop1 in range(0,len(src)):
		for loop2 in range(0,len(dest)):
			src_local=src_img[src[loop1,0]-W_half:src[loop1,0]+W_half+1,src[loop1,1]-W_half:src[loop1,1]+W_half+1]
			dest_local=dest_img[dest[loop2,0]-W_half:dest[loop2,0]+W_half+1,dest[loop2,1]-W_half:dest[loop2,1]+W_half+1]
			ssd_calc=np.square(np.subtract(src_local,dest_local))
			ssd_mat[loop1,loop2]=np.sum(ssd_calc)
	pts=[]
	# Obtaining the corresponding points which are best match in both the images
	for loop1 in range(0,len(src)):
		for loop2 in range(0,len(dest)):
			# Eliminating weak correspondence
			if ssd_mat[loop1,loop2]==np.min(ssd_mat[loop1,:]) and ssd_mat[loop1,loop2]<T_min_global*np.mean(np.abs(ssd_mat)):
				loc_min=ssd_mat[loop1,loop2]
				ssd_mat[loop1,loop2]=np.max(ssd_mat[loop1,:])
				# Eliminating false positives as much as possible
				if loc_min/np.min(ssd_mat[loop1,:]) < T_ssd:
					# Set the column of loop2 to arbitary highest value to remove many to one results 
					ssd_mat[:,loop2]=np.max(ssd_mat)
					# Set the [loop1,loop2] value to original, else it will have one to many results 
					ssd_mat[loop1,loop2]=loc_min					
					pts.append([src[loop1,0],src[loop1,1],dest[loop2,0],dest[loop2,1]])
					      
        # return the corresponding points as array
        return np.asarray(pts)
# Function to find the Sum of Least squares for each level ends here
#########################################

#########################################
# Function to find the Normalised Cross Corelation for each level starts here
def NCC_images(Corner_Coord1,Corner_Coord2,img_1,img_2,W_size,T_ncc,T_max_global):
        """ Code for NCC to correlate between two views of the same image
        """ 
	# Creating the window size for find the descriptors for the corner
	W_half=int(W_size/2)
	src=Corner_Coord1
	dest=Corner_Coord2
	src_img=img_1
	dest_img=img_2
	src_mat=np.zeros((len(src),len(dest)),dtype='float')
	# Calculating NCC for all points
	for loop1 in range(0,len(src)):
		for loop2 in range(0,len(dest)):
			src_local=src_img[src[loop1,0]-W_half:src[loop1,0]+W_half+1,src[loop1,1]-W_half:src[loop1,1]+W_half+1]
			dest_local=dest_img[dest[loop2,0]-W_half:dest[loop2,0]+W_half+1,dest[loop2,1]-W_half:dest[loop2,1]+W_half+1]
			src_mean=np.mean(src_local)
			dest_mean=np.mean(dest_local)
			src_norm=np.subtract(src_local,src_mean)
			dest_norm=np.subtract(dest_local,dest_mean)
			num=np.sum(np.multiply(src_norm,dest_norm))
			src_sq=np.sum(np.square(src_norm))
			dest_sq=np.sum(np.square(dest_norm))
			den=np.sqrt(src_sq*dest_sq)
			src_mat[loop1,loop2]=num/den
	pts=[]
	
	# Obtaining the corresponding points which are best match in both the images
	for loop1 in range(0,len(src)):
		for loop2 in range(0,len(dest)):
			# Eliminating weak correspondence
			if src_mat[loop1,loop2]==np.max(src_mat[loop1,:]) and src_mat[loop1,loop2]>T_max_global*np.max(src_mat):
				loc_max=src_mat[loop1,loop2]
				src_mat[loop1,loop2]=np.min(src_mat[loop1,:])
				# Eliminating false positives as much as possible
				if np.max(src_mat[loop1,:])/loc_max < T_ncc:
					# Set the column of loop2 to zero in order to remove many to one results 
					src_mat[:,loop2]=0
					# Set the [loop1,loop2] value to original, else it will have one to many results
					src_mat[loop1,loop2]=loc_max					
					pts.append([src[loop1,0],src[loop1,1],dest[loop2,0],dest[loop2,1]])
	# return the corresponding points as array				
        return np.asarray(pts)
# Function to find the Normalised Cross Corelation for each level ends here
#########################################

            
