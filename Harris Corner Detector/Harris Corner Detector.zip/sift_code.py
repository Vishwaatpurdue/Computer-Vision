"""
author: Vishveswaran Jothi
"""
import cv2
import numpy as np

###########################################
# Function to detect and compute keypoints using SIFT is implemented here
def SIFT_detector(img,f_count,sig,layers):
	
	img_gray=cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
	# creating a sift detector
	SIFT = cv2.xfeatures2d.SIFT_create(nfeatures=f_count,nOctaveLayers=layers,contrastThreshold=0.03,edgeThreshold=10,sigma=sig)
	# Applying Sift detector to the image
	keypoints, descriptor = SIFT.detectAndCompute(img_gray,None)
	outImg=0
	# Plotting the keypoints along with their scale
	img = cv2.drawKeypoints(img, keypoints,outImg,flags=cv2.DRAW_MATCHES_FLAGS_DRAW_RICH_KEYPOINTS)
	pts=[]
	# Obtaining keypoints from the object keypoint
	for keypoint in keypoints:
		pts.append([np.round(keypoint.pt[0],0),np.round(keypoint.pt[1],0)])	
	# Returning the plotted image, keypoints and the descriptors
	return img,np.asarray(pts,dtype='int'),np.asarray(descriptor)

###########################################

###########################################
# Function to compute SSD starts here
def SSD(kp1,des1,kp2,des2,T_ssd,T_min_global):
	# Calculating SSD to correlate between two images
	ssd_mat=np.zeros((len(kp1),len(kp2)),dtype='float')
	for loop1 in range(0,len(kp1)):
		for loop2 in range(0,len(kp2)):
			ssd_calc=np.square(np.subtract(des1[loop1,:],des2[loop2,:]))
			ssd_mat[loop1,loop2]=np.sum(ssd_calc)
	pts=[]
	# Eliminate weak correspondences
	for loop1 in range(0,len(kp1)):
		for loop2 in range(0,len(kp2)):
			if ssd_mat[loop1,loop2]==np.min(ssd_mat[loop1,:]) and ssd_mat[loop1,loop2]<T_min_global*np.mean(ssd_mat):
				loc_min=ssd_mat[loop1,loop2]
				ssd_mat[loop1,loop2]=np.max(ssd_mat[loop1,:])
				# Eliminate false positive correspondences by thresholding
				if loc_min/np.min(ssd_mat[loop1,:])<T_ssd:
					ssd_mat[:,loop2]=np.max(src_mat)
					ssd_mat[loop1,loop2]=loc_min					
					pts.append([kp1[loop1,0],kp1[loop1,1],kp2[loop2,0],kp2[loop2,1]])
					  
        return np.asarray(pts)
# Function to compute SSD ends here 
###########################################

###########################################
# Function to find the Normalised Cross Corelation for each level starts here
def NCC(kp1,des1,kp2,des2,T_ncc,T_max_global):
        """ Code for NCC to correlate between two views of the same image
        """ 
	src_mat=np.zeros((len(kp1),len(kp2)),dtype='float')
	for loop1 in range(0,len(kp1)):
		for loop2 in range(0,len(kp2)):
			src_mean=np.mean(des1[loop1,:])
			dest_mean=np.mean(des2[loop2,:])
			src_norm=np.subtract(des1[loop1,:],src_mean)
			dest_norm=np.subtract(des2[loop2,:],dest_mean)
			num=np.sum(np.multiply(src_norm,dest_norm))
			src_sq=np.sum(np.square(src_norm))
			dest_sq=np.sum(np.square(dest_norm))
			den=np.sqrt(src_sq*dest_sq)
			src_mat[loop1,loop2]=num/den
	pts=[]
	
	# Eliminate weak correspondences
	for loop1 in range(0,len(kp1)):
		for loop2 in range(0,len(kp2)):
			if src_mat[loop1,loop2]==np.max(src_mat[loop1,:]) and src_mat[loop1,loop2]>T_max_global*np.max(src_mat):
				loc_max=src_mat[loop1,loop2]
				src_mat[loop1,loop2]=np.min(src_mat[loop1,:])
				# Eliminate false positive correspondences by thresholding 
				if np.max(src_mat[loop1,:])/loc_max < T_ncc:
					src_mat[:,loop2]=0
					src_mat[loop1,loop2]=loc_max					
					pts.append([kp1[loop1,0],kp1[loop1,1],kp2[loop2,0],kp2[loop2,1]])
					
        return np.asarray(pts)
# Function to find the Normalised Cross Corelation for each level ends here
###########################################

###########################################
def plotting(Corner_Coord,img1,img2):
	# creating a base image which has image 1 and image 2
    	img=np.zeros((max(img1.shape[0],img2.shape[0]),img1.shape[1]+img2.shape[1],3))
    	img[:img1.shape[0], :img1.shape[1]]=img1
    	img[:img2.shape[0], img1.shape[1]:img1.shape[1]+img2.shape[1]]=img2
	output=img
	# plotting the correspondence using lines
	for coord in Corner_Coord:
		output=cv2.line(output,(coord[0],coord[1]),(img1.shape[1]+coord[2],coord[3]), (0,0,255))
	return output
###########################################

###########################################
# Obtaining input from the user
###########################################
path = "Enter the full path for the images:"
img_name = "Enter the image name with file type/ file extension:"
sigma_prompt = "Enter the sigma (Kernel size):"
F_prompt = "Enter the no. of features in which SIFT needs to be detected:"

T_ncc_prompt="Enter the value of threshold for NCC metrics (0.6~0.9)"
T_max_global_prompt="Enter the value of threshold for finding keypoint among global maximums \n Lower the value to get more keypoints... (0.2~0.8)  "
T_ssd_prompt="Enter the value of threshold for SSD metrics (0.7~0.9)"
T_min_global_prompt="Enter the value of threshold for finding keypoint among global minimums \n Increase the value to get more keypoints... (3~7)  "

file_path=raw_input(">"+path)
img_name1=raw_input(">"+img_name)
img_name2=raw_input(">"+img_name)
sigma=float(raw_input(">"+sigma_prompt))
f_count=raw_input(">"+F_prompt)

T_ncc=int(raw_input(">"+T_ncc_prompt))
T_max_global=int(raw_input(">"+T_max_global_prompt))
T_ssd=int(raw_input(">"+T_ssd_prompt))
T_min_global=int(raw_input(">"+T_min_global_prompt))
img_1=cv2.imread(path+"/"+img_name1)
img_2=cv2.imread(path+"/"+img_name2)
"""
###########################################

###########################################
# Sample input code for referrence
###########################################
#img_1=cv2.imread("/tmp/guest-yjcfUT/661/Hw4/HW4Pics/pair1/1.jpg")
#img_2=cv2.imread("/tmp/guest-yjcfUT/661/Hw4/HW4Pics/pair1/2.jpg")
img_1=cv2.imread("/tmp/guest-yjcfUT/HW4Pics/pair4/1.jpg")
img_2=cv2.imread("/tmp/guest-yjcfUT/HW4Pics/pair4/2.jpg")

layers=4
sigma=1.4
T_ncc=0.8
T_max_global=0.9
T_ssd=0.4
T_min_global=5
f_count=100
"""
###########################################

###########################################
# Computing SIFT keypoints
###########################################
img1, kp1, desp1 = SIFT_detector(img_1,f_count,sigma,layers)
img2, kp2, desp2 = SIFT_detector(img_2,f_count,sigma,layers)
cv2.imwrite('test.jpg',img1)
###########################################

###########################################
# Computing correspondence using SSD
###########################################
Coord_SSD=SSD(kp1,desp1,kp2,desp2,T_ssd,T_min_global)
img=plotting(Coord_SSD,img1,img2)
cv2.imwrite('Pair4_SSD_0.4_5_100.jpg',img)
###########################################

###########################################
# Computing correspondence using NCC
###########################################
Coord_NCC=NCC(kp1,desp1,kp2,desp2,T_ncc,T_max_global)
img=plotting(Coord_NCC,img1,img2)
cv2.imwrite('Pair4_NCC_0.9_0.9_100.jpg',img)
###########################################

