
"""
@author: Vishveswaran Jothi
"""
import cv2
import numpy as np
from util import *


def Homography(pt):
	l=np.zeros((5,3),dtype='float')
	m=np.zeros((5,3),dtype='float')
	l[0]=np.cross(pt[0,:],pt[2,:])
	m[0]=np.cross(pt[0,:],pt[1,:])
	l[1]=np.cross(pt[0,:],pt[1,:])
	m[1]=np.cross(pt[1,:],pt[3,:])
	l[2]=np.cross(pt[2,:],pt[3,:])
	m[2]=np.cross(pt[1,:],pt[3,:])
	l[3]=np.cross(pt[2,:],pt[3,:])
	m[3]=np.cross(pt[0,:],pt[2,:])
	l[4]=np.cross(pt[4,:],pt[7,:])
	m[4]=np.cross(pt[5,:],pt[6,:])
	Mat_A=np.zeros((5,5),dtype='float')
	b=np.zeros((5,1),dtype='float')
	X=np.zeros((5,1),dtype='float')
	S=np.zeros((2,2),dtype='float')
	A=np.zeros((2,2),dtype='float')	
	#Normalizing the lines and setting Matrices A,b
	for i in range(0,5):	
		l[i]=l[i]/l[i,2]
		m[i]=m[i]/m[i,2]
		Mat_A[i]=np.array([l[i,0]*m[i,0], 0.5*(l[i,1]*m[i,0]+l[i,0]*m[i,1]), l[i,1]*m[i,1], 0.5*(l[i,0]*m[i,2]+l[i,2]*m[i,0]), 0.5*(l[i,2]*m[i,1]+l[i,1]*m[i,2])])
		b[i]=-l[i,2]*m[i,2]
	#loop ends here
	X=np.dot(np.linalg.pinv(Mat_A),b)
	S[0,0]=X[0]
	S[0,1]=X[1]/2
	S[1,1]=X[2]
	S[1,0]=S[0,1]
	print S
	U,D,V=np.linalg.svd(S)
	D_A=np.diag(np.sqrt(D))
	A=np.dot(V,np.dot(D_A,V.T))
	v=np.zeros((2,1))
	de_vec=np.zeros((2,1))
	de_vec[0]=0.5*X[3]
	de_vec[1]=0.5*X[4]
	v=np.dot(np.linalg.pinv(A),de_vec)
	#v=v/np.sqrt((v.T.dot(v)))
	H=np.zeros((3,3))
	H[0]=np.array([A[0,0],A[0,1],0])
	H[1]=np.array([A[1,0],A[1,1],0])
	H[2]=np.array([v[0],v[1],1])
	return H
#######################################################
path="/home/vishwa/661/Hw3/HW3Pics"

image1=cv2.imread(path+"/flatiron.jpg")
#image1=cv2.imread("flatironS.jpg")
#points=np.array([[272,98,1],[154,552,1],[491,30,1],[413,580,1],[254,383,1],[220,537,1],[363,376,1],[331,546,1]],dtype='float64')
points=np.array([[272,98,1],[154,552,1],[491,30,1],[413,580,1],[321,313,1],[256,363,1],[367,356,1],[295,426,1]],dtype='float64')
H=Homography(points)
invH=np.linalg.inv(H)
print image1.shape
[Off_X,Off_Y,Dim_X,Dim_Y]= dimension_offset(invH,image1)
print [Off_X,Off_Y,Dim_X,Dim_Y]
output_persp=image_mapping(image1,invH,Off_X,Off_Y,Dim_X,Dim_Y)
cv2.imwrite('step1.jpg',output_persp)


