"""
@author: vishwa
"""

import cv2
import numpy as np
from util import *
path = "/home/vishwa/661/Hw3/HW3Pics"

# Function for finding Homography starts here

def Homography_coords(points_src,points_dest):
    # Initialize A, b in equation Ax=b w.r.t input points
    Mat_A=np.zeros((points_src.shape[0]*2,8),dtype='float')
    b = np.zeros((1,points_src.shape[0]*2),dtype='float')
    if points_src.shape[0] != points_dest.shape[0] or points_src.shape[1] != points_dest.shape[1]:
        print "No. of Source and destination points donot match"
        exit(1)
    for i in range(0,len(points_src)):
        Mat_A[i*2]=[points_src[i][0],points_src[i][1],points_src[i][2],0,0,0,(-1*points_src[i][0]*points_dest[i][0]),(-1*points_src[i][1]*points_dest[i][0])]
        Mat_A[i*2+1]=[0,0,0,points_src[i][0],points_src[i][1],points_src[i][2],(-1*points_src[i][0]*points_dest[i][1]),(-1*points_src[i][1]*points_dest[i][1])]
        b[0][i*2] = points_dest[i][0]
        b[0][i*2+1] = points_dest[i][1]        
    # A, b matrix formed
      
    # If no. of points is not 4 then using the below code
    tmp_H=np.dot(np.linalg.pinv(Mat_A),b.T)
    homography= np.zeros((3,3))
    homography[0]= tmp_H[0:3,0]
    homography[1]= tmp_H[3:6,0]
    homography[2][0:2]= tmp_H[6:8,0]
    homography[2][2]= 1
    return homography
# Function for finding Homography ends here

#Input code Begins here
image_1 = cv2.imread(path+"/wideangle.jpg")



# Homogeneous points obtained from gimp

# Frame Coordinates for Monalisa.jpg
Points_1atrymona=np.array([[115,289,1],[148,449,1],[368,258,1],[384,419,1]])

Points_1b=np.array([[795,1590,1],[768,2983,1],[1597,1616,1],[1518,2987,1]])
# Frame Coordinates for Wideangle.jpg
Points_1atry2=np.array([[234,101,1],[249,164,1],[314,92,1],[330.7,154,1]])

# World Coordinates
# Coordinates for Flatiron.jpg
Points_1W=np.array([[0,0,1],[0,100,1],[150,0,1],[150,100,1],])
# Coordinates for Monalisa.jpg
Points_2W=np.array([[0,0,1],[0,60,1],[100,0,1],[100,60,1]])
# Coordinates for Wideangle.jpg
Points_3W=np.array([[0,0,1],[0,70,1],[120,0,1],[120,70,1]])

# creating homography for Flatiron
H1= Homography_coords(Points_1atry2,Points_3W)
print H1
# Generating the real world coordinates and offsets for the image in the image plane
[Off_X,Off_Y,Dim_X,Dim_Y]= dimension_offset(H1,image_1)
H_inv=np.linalg.inv(H1)
output_persp=image_mapping(image_1,H1,Off_X,Off_Y,Dim_X,Dim_Y)
cv2.imwrite('bonus_proj3.jpg',output_persp)
input_aff_1=output_persp

# Points to find pair of line that will be orthogonal in undistorted image
points_affine_1=np.array([[246,669,1],[262,611,1],[404,621,1],[135,463,1],[62,592,1],[206,634,1]])
H_Affine=Homography_Affine(points_affine_1)
H_Affine_inv=np.linalg.inv(H_Affine)
[Off_XA,Off_YA,Dim_XA,Dim_YA] = dimension_offset(H_Affine_inv,input_aff_1)
output_affine=image_mapping(input_aff_1,H_Affine_inv,Off_XA,Off_YA,Dim_XA,Dim_YA)
cv2.imwrite('bonus_wide_affine.jpg',output_affine)

