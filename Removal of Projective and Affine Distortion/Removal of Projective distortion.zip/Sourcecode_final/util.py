import cv2
import numpy as np
import math

# Finding dimension and offset function starts here
def dimension_offset(Hom,src_image):
	Points=np.array([[0,0,1],[0,src_image.shape[1],1],[src_image.shape[0],0,1],[src_image.shape[0],src_image.shape[1],1]])
	tmp=np.zeros((Points.shape[1],Points.shape[0]))
	tmp=np.array((np.dot(Hom,Points.T)).T)
	for i in range(0,Points.shape[0]):
		tmp[i]=tmp[i]/tmp[i,2]
	tmp=tmp.T ; print tmp
      
	# Generating Offsets and New Dimensions
	offset_X=round(min(tmp[0]))
	offset_Y=round(min(tmp[1]))
	dim_X=(max(tmp[0])-offset_X)
	dim_Y=(max(tmp[1])-offset_Y)	
	return offset_X,offset_Y,dim_X,dim_Y
# Finding dimension and offset function ends here

# Getting RGB data function using weighted average starts here
def getdata(point, img):
    tp_left =img[(math.floor(point[0])),(math.floor(point[1]))]
    tp_right =img[math.floor(point[0]),math.floor(point[1]+1)]
    bt_left =img[math.floor(point[0]+1),math.floor(point[1])]
    bt_right =img[math.floor(point[0]+1),math.floor(point[1]+1)]
    diff_x = point[0] - math.floor(point[0])
    diff_y = point[1] - math.floor(point[1])
    tp_left_weight= pow(pow(diff_x,2)+pow(diff_y,2),-0.5)
    tp_right_weight = pow(pow(diff_x,2)+pow(1-diff_y,2),-0.5)
    bt_left_weight = pow(pow(1-diff_x,2)+pow(diff_y,2),-0.5)
    bt_right_weight = pow(pow(1-diff_x,2)+pow(1-diff_y,2),-0.5)
    resultant_pt = (tp_left*tp_left_weight+tp_right*tp_right_weight+bt_left*bt_left_weight+bt_right*bt_right_weight)/(tp_left_weight+tp_right_weight+bt_left_weight+bt_right_weight)
    return resultant_pt
# getting RGB data function using weighted average ends here
   
# Image mapping code starts here
def image_mapping(dest_image,Homography,Off_X,Off_Y,Dim_X,Dim_Y):
	# creating aspect ratio to scale the image to appropriate size
	Aspect_ratio=float(Dim_Y)/float(Dim_X)
	if Dim_Y<Dim_X:	
		Dim_World_Y=dest_image.shape[1]
		Dim_World_X=math.ceil(Dim_World_Y/Aspect_ratio)
	else:
		Dim_World_X=dest_image.shape[0]
		Dim_World_Y=math.ceil(Dim_World_X*Aspect_ratio)
	# Determining Scaling factor for each pixel
	p_ht=Dim_X/Dim_World_X
	p_wd=Dim_Y/Dim_World_Y
	# creating a base image for the projecting the corrected image
	tmp_srcimage=np.zeros((int(Dim_World_X),int(Dim_World_Y),3),dtype='uint8')
	invHom=np.linalg.inv(Homography)
	for i in range(0,int(Dim_World_X)):
		for j in range(0,int(Dim_World_Y)):
			point_tmp = np.array([i*p_ht, j*p_wd, 1])
			point_new = point_tmp+np.array([Off_X, Off_Y, 0])
			trans_coord = np.array(np.dot(invHom,point_new))
			trans_coord = trans_coord/trans_coord[2]
			if (trans_coord[0]>0) and (trans_coord[0]<dest_image.shape[0]-1) and (trans_coord[1]>0) and (trans_coord[1]<dest_image.shape[1]-1):
				tmp_srcimage[i][j]=getdata(trans_coord,dest_image)
	return tmp_srcimage
# Image mapping code ends here

########################################################################
# Finding homography to remove perspective distortion
# Function to find homography using 2 pair of parallel lines
def per_hom_lines(points):
	""" As per notes Finding the cross product of the two points to find the line connecting the points
	l1 is formed by the cross product of P,Q. l1 is formed by the cross product of P,Q. l3 is formed by P,R and l4 is formed by Q,S """
	l1= np.cross((points[2,:]),(points[3,:]))
 	l2= np.cross(points[0,:],points[1,:])
	l3= np.cross(points[2,:],points[0,:])
	l4= np.cross(points[3,:],points[1,:])
	# Normalizing the lines
	l1_n= l1/l1[2]
	l2_n= l2/l2[2]
	l3_n= l3/l3[2]
	l4_n= l4/l4[2]
	"""Finding the two ideal points by the cross product of the lines obtained A = cross product l1 and l2. while B= crossproduct of l3 and l4."""
	A= np.cross(l3_n,l4_n)
	B= np.cross(l1_n,l2_n)
	# Normalizing the points
	A_n= A/A[2]
	B_n= B/B[2]
	""" Finding the line at infinity. Normalizing the line at infinity"""
	l_inf= np.cross(A_n,B_n) 	
 	l_inf_n= l_inf/l_inf[2]
	# Generating homography matrix
	H = np.array([[1.0,0,0],[0,1.0,0],[0,0,0]])
	H[2] = l_inf_n
	return H
# Function to find homography using 2 pair of parallel lines ends here

# Finding Lines
def Lines(point1,point2):
	Line=np.cross(point1,point2)
	return Line
# Finding the lines between two points ends here

# Image mapping code ends here. 
""" Removing Affine Distortion"""
# Finding Homography of Affine
def Homography_Affine(points):
	# Finding two orthogonal lines from 3 points
	L1=Lines(points[1,:],points[0,:])
	M1=Lines(points[1,:],points[2,:])
	L2=Lines(points[4,:],points[3,:])
	M2=Lines(points[4,:],points[5,:])
	# Find S matrix from linear quation s=(A^-1)*b
	Mat_A=np.zeros((2,2),dtype='float')
	b=np.array([0,0])
	Mat_A[0]=np.array([L1[0]*M1[0],(M1[0]*L1[1]+M1[1]*L1[0])])
	Mat_A[1]=np.array([L2[0]*M2[0],(M2[0]*L2[1]+M2[1]*L2[0])])
	b=np.array([-M1[1]*L1[1],-M2[1]*L2[1]])
	[s11, s12]= (np.linalg.pinv(Mat_A).dot(b))
	print s11,s12
	S=np.zeros((2,2),dtype='float')
	# Generating S matrix which is ATA
	S[0]=np.array([s11,s12])
	S[1]=np.array([s12,1])
	# Find SVD decomposition of S to find A
	V,D_S,Vt=np.linalg.svd(S,full_matrices=1)
	D_A=np.sqrt(D_S)
	# Reconstructing D_A matrix from the S
	D = np.zeros((2,2),dtype='float')
	D[0]= np.array([D_A[0],0])
	D[1]= np.array([0,D_A[1]])
	A=V.dot(D).dot(V.T)
	# Finally the homography is 
	H=np.array([[A[0,0],A[0,1],0],[A[1,0],A[1,1],0],[0,0,1]])
	return H
# Homography for affine ends here
