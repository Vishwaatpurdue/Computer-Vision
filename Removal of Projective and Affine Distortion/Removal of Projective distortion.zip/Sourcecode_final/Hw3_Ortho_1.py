"""
@author: Vishveswaran Jothi
"""

import cv2
import numpy as np
import math
from util import *

#path where the files are located
path = "/home/vishwa/661/Hw3/HW3Pics"

# Input images
image_1 = cv2.imread(path+"/flatiron.jpg")

# Points obtained from gimp converted into homogeneous coordinates
# Frame Coordinates for Flatiron.jpg
Points_1=np.array([[273,96,1],[153,552,1],[493,28,1],[412,581,1]],dtype='float')
H_persp = per_hom_lines(Points_1)
[Off_X,Off_Y,Dim_X,Dim_Y]= dimension_offset(H_persp,image_1)
output_persp=image_mapping(image_1,H_persp,Off_X,Off_Y,Dim_X,Dim_Y)
cv2.imwrite('ortho_1_persp.jpg',output_persp)
input_aff_1=output_persp
# Points to find pair of line that will be orthogonal in undistorted image
points_affine_1=np.array([[310,246,1],[343,230,1],[331,260,1],[310,246,1],[298,278,1],[331,260,1]])
H_Affine=Homography_Affine(points_affine_1)
H_Affine_inv=np.linalg.inv(H_Affine)
[Off_XA,Off_YA,Dim_XA,Dim_YA] = dimension_offset(H_Affine_inv,input_aff_1)
output_affine=image_mapping(input_aff_1,H_Affine_inv,Off_XA,Off_YA,Dim_XA,Dim_YA)
cv2.imwrite('ortho_1_affine.jpg',output_affine)

####################################################

