%% Main function for image classification based on textures
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Getting input from the user
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%path_prompt='Enter the path of the training folder:';
%radius_prompt='Enter the radius to choose the points:';
%points_prompt='Enter the no. of points around the pixel to describe the feature(min value: 8):';
%ext_prompt='Enter the extension as (*.jpg) format:';
%path_test_prompt='Enter the path of the testing folder:';
%path=input(path_prompt);
%radius=input(radius_prompt);
%points=input(points_prompt);
%ext=input(ext_prompt);
%path_test=input(path_test_prompt);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sample data provided for reference
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

folders={'building','car','mountain', 'tree'};
path='/home/vishwa/661/HW8/HW8PICS/imagesDatabaseHW8/training/';
radius=1;
points=8;
ext='*.jpg';
path_test='/home/vishwa/661/HW8/HW8PICS/imagesDatabaseHW8/testing/';
pathfile='/home/vishwa/661/HW8/HW8PICS/imagesDatabaseHW8/training/';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Main algorithm starts here
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
files=dir(strcat(pathfile));
x_features=zeros(length(files)*length(folders)-4,points+2);
y_train=zeros(size(x_features,1),1);
folder=dir(path);
fprintf('Loading data....\n');
% since it takes . and .. folder inside the main directory loop starts at 3
for outerloop=3:length(folder)
 
    fold_name=folder(outerloop).name;
    inner_path=strcat(path,fold_name,'/');
    files=dir(strcat(inner_path,ext));
    % obtaining images inside the training folder
    for loop= 1:length(files)
        image_path=strcat(inner_path,files(loop).name);
        imag=imread(image_path);
        % converting images into gray scale images
        image=rgb2gray(imag);
        % extracting feature points
        feature=LBP(image,radius,points);
        increment=(outerloop-3)*20;
        % storing features as x_features
        x_features(loop+increment,:)=feature;
        % creating result for training data
        y_train(loop+increment)=outerloop-2;
    end
end
fprintf('Features extraction completed for training dataset...\n');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Training using knn 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% normalizing the feature vectors/ feature matrix w.r.to each row
lbp_hist=x_features;
x_features=normr(x_features);
% display the histogram for each class of classification

mdl=fitcknn(x_features,y_train,'NumNeighbors',5,'Distance','euclidean','Standardize',1);
fprintf('Dataset trained using knn.. \n');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Extracting features for test dataset
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
fprintf('Testing with the test data provided in another subfolder..\n');
test_files=dir(path_test);
% creating base for test parameters
x_test=zeros(length(test_files)-2,points+2);
y_test=zeros(length(test_files)-2,1);
% extracting the feature set ofr each image
for testloop=3:length(test_files)
   imag=imread(strcat(path_test,test_files(testloop).name));
   image=rgb2gray(imag);
   feature=LBP(image,radius,points);
   x_test(testloop-2,:)=feature;
   % generating result of the test dataset
   for resultloop=1:length(folders)
       base=test_files(testloop).name;
       if(strfind(base,folders(resultloop))>-1)
          y_test(testloop-2)=resultloop;
       end
   end
end
% normalizing test vector w.r. to each row
x_test=normr(x_test);
fprintf('Feature extraction for test data completed.....\n'); 
y_predict=predict(mdl,x_test);
% Also my implementation can used which is provided as kNN
% to do so uncomment the below line.
%y_predict=kNN(x_features,y_train,x_test,5,'euclidean');

fprintf('Data Evaluated.....\n');
diff=y_test-y_predict;
matches=0;
for i=1:length(diff)
    if(diff(i)==0)
        matches=matches+1;
    end
end
accuracy=matches*100/length(diff);
fprintf('Accuracy of the knn based on the feature extraction is %f %...\n',accuracy);
% plotting confusion matrix
plotconf(y_test,y_predict,length(folders));



 