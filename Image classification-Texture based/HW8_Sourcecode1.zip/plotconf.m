%% Plotting confusion matrix
function plotconf(y_predict,y_test,class_types)
% generating base matrices
y_org=zeros(length(y_predict),class_types);
y_pre_conf=zeros(length(y_predict),class_types);
% Generating output matrices in which each column represents unique classes
% for claasification
for i=1:length(y_predict)
    for j=1:class_types
        if(y_predict(i)==j)
            y_pre_conf(i,j)=1;
        end
        if(y_test(i)==j)
            y_org(i,j)=1;
        end

    end
end
figure;
% Plotting and saving Confusionplot for further analysis
plotconfusion(y_pre_conf',y_org');
saveas(figure(1),'ConfusionPlot_Output_R_1_P_8test.jpg');
end
