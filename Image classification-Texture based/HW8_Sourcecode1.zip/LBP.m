%% LBP Implementation

function lbp_histogram = LBP(image,Radius,Points)
%Finding rows and columns of the image
[rows,cols]=size(image);
rows=rows-Radius;
cols=cols-Radius;
% create a base histogram
lbp_histogram=zeros(Points+2,1);
for row = Radius+1:rows
    for col=Radius+1:cols
        
        pattern1=zeros(Points,1);
        for p = 1:Points
            % Define del_u, del_v
            del_v=Radius*sind(360*(p-1)/Points);
            del_u=Radius*cosd(360*(p-1)/Points);
            v=col+del_v;
            u=row+del_u;
            x=floor(u);
            y=floor(v);
            % Implementing Bilinear transformation with delta values as
            % Delta_U,Delta_V
            Delta_V=v-y;
            Delta_U=u-x;
            if(Delta_U ==0 && Delta_V ==0)
                val_p=image(x,y);
            elseif(Delta_U ==0)
              val_p=(1-Delta_V)*image(x,y)+Delta_V*image(x,y+1);
            elseif(Delta_V ==0)
              val_p=(1-Delta_U)*image(y,x)+Delta_U*image(x+1,y);
            else
                
               val_p=(1-Delta_U)*(1-Delta_V)*image(x,y)+Delta_U*(1-Delta_V)*image(x+1,y)+(1-Delta_U)*Delta_V*image(x,y+1)+Delta_U*Delta_V*image(x+1,y+1);
            end
            % generating the pattern by comparing the current base pixel
            % intensity value with the interpolated value
            if(val_p>=image(row,col))
                
                pattern1(p)=1;
            end
        end
        % find the position w.r.to features (making rotation invariant)
        pos=Bitcount(pattern1,Points);
        % generating histogram of the lbp feature extraction method
        lbp_histogram(pos)=lbp_histogram(pos)+1;
        
    end
end
end

%%