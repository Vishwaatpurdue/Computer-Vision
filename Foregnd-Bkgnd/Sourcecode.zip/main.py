"""
Author: Vishveswaran jothi
"""
import cv2
import numpy as np
import otsu as Alg
import Extract_contour as EC

####################################
#Input from the user
####################################

"""
path_prompt = "Enter the full path for the images:"
img_name_prompt = "Enter the image name with file type/ file extension:"
tex_prompt= "Enter "yes" for texture and "no" for normal procedure:"
iteration_prompt="Enter iteration value:"
path=raw_input(">"+path_prompt)
img_name=raw_input(">"+img_name_prompt)
tex=raw_input(">"+tex_prompt)
iter1 = np.array([0,0,0])
MASK_param = np.array([0,0,0])
for loop in range(3):
    iter1[loop] =int(raw_input(">"+iter_prompt))
for loop in range(3):
    MASK_param[loop] =int(raw_input(">"+iter_prompt))
        
"""
####################################
# Sample Input from the user
####################################
# if you are using texture set the MASK_param to (1,1,1) and iteration to (1,1,1)else give appropriate 
# parameter to get better results
path="/home/vishwa/661/HW6/HW6Pics"
img_name1="lake.jpg"
img_name2="leopard.jpg"
img_name3="brain.jpg"
tex='yes'
iter1 =np.array([1,1,1])
MASK_param=np.array([1,1,1])
img_name=img_name3.split('.')[0]
###################################
#Algorithm starts here
###################################

img=cv2.imread(path+'/'+img_name3)
img_R=np.zeros_like(img)
img_G=np.zeros_like(img)
img_B=np.zeros_like(img)
# separate the three colors
img_B[:,:,0]=img[:,:,0]
img_G[:,:,1]=img[:,:,1]
img_R[:,:,2]=img[:,:,2]

cv2.imwrite(img_name+'R.jpg',img_R)
cv2.imwrite(img_name+'B.jpg',img_B)
cv2.imwrite(img_name+'G.jpg',img_G)

####################################
#Calling Otsu algorithm
####################################
binary=Alg.Otsu(img,iter1,tex,MASK_param,img_name)

output=EC.bk_fg(binary)
#output=EC.fg_bk(binary)

# Extraction of final contour of foreground
final_output=EC.contour(output)
cv2.imwrite(img_name+'_finalbk_fg_tex.jpg',final_output)
output=EC.fg_bk(binary)
final_output=EC.contour(output)
cv2.imwrite(img_name+'_finalfg_bk_tex.jpg',final_output)
"""
Lake- RGB
iter1 =np.array([1,4,3])
MASK_param=np.array([1,0,0])
kernel = 7,7 and 15,15
Lake- TEX
iter1 =np.array([1,1,1])
MASK_param=np.array([1,1,1])

Leopard - RGB
iter1 =np.array([1,1,1])
MASK_param=np.array([1,1,1])
kernel = 7,7 and 5,5
EC.fg_bk
Leopard - TEX
iter1 =np.array([1,1,1])
MASK_param=np.array([1,1,1])

Brain - RGB
iter1 =np.array([3,3,3])
MASK_param=np.array([1,1,1])
kernel = 7,7 and 5,5
EC.fg_bk
Brain - TEX
iter1 =np.array([1,1,1])
MASK_param=np.array([1,1,1])
"""
