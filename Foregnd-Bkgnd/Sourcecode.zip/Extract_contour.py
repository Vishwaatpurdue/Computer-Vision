"""
Author: Vishveswaran jothi
"""
import cv2
import numpy as np
###############################################
# Contour Extraction starts here
###############################################
def contour(img):
    # creating a base image
    output=np.zeros_like(img)
    for loop1 in range(1,img.shape[0]):
        for loop2 in range(1,img.shape[1]):
            # searching for borders and locating only borders
            local_sec=img[loop1-1:loop1+2,loop2-1:loop2+2]
            if img[loop1,loop2]!=0 and np.min(local_sec)==0:
                output[loop1,loop2]=255
    return output
###############################################
# Contour Extraction ends here
###############################################

###############################################
# Noise reduction starts here
###############################################
def fg_bk(binary):
    # To remove the noise in foreground
    # kernel size is manually fixed after many trial and errors
    kernel= np.ones((7,7),dtype='uint8')
    dilate= cv2.dilate(binary,kernel)
    erode=cv2.erode(dilate,kernel)
    
    # To remove the noise in background
    # kernel size is manually fixed after many trial and errors
    kernel= np.ones((5,5),dtype='uint8')
    erode=cv2.erode(erode,kernel)
    output= cv2.dilate(erode,kernel)
    return output
###############################################
# Noise reduction ends here
###############################################

###############################################
# Noise reduction starts here
###############################################
def bk_fg(binary):
    
    # To remove the noise in background
    # kernel size is manually fixed after many trial and errors
    kernel= np.ones((7,7),dtype='uint8')
    erode=cv2.erode(binary,kernel)
    dilate= cv2.dilate(erode,kernel)

    # To remove the noise in foreground
    # kernel size is manually fixed after many trial and errors
    kernel= np.ones((5,5),dtype='uint8')
    dilate= cv2.dilate(dilate,kernel)
    output=cv2.erode(dilate,kernel)
    
    return output
###############################################
# Noise reduction ends here
###############################################