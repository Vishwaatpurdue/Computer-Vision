"""
Author: Vishveswaran jothi
"""
import cv2
import numpy as np

###############################################
# OTSU Algorithm for all channels starts here
###############################################
def Otsu(img,iter1,texture,MASK_param,img_name):
    if texture =='yes':
        output=texture_img(img)
    else:
        output=img
    # Create the overall mask
    mask_final=np.zeros_like(img[:,:,0])
    mask_final.fill(255)  
    
    for channel in range(3):
        binary = None
        for loop2 in range(iter1[channel]):
            # Otsu Algorithm
            binary=algorithm_otsu(output[:,:,channel],binary)
        # calculating the overall mask as the logic opeation on individual mask
        if MASK_param[channel]==1:
            mask_final=cv2.bitwise_and(mask_final,binary)
        else:
            mask_final=cv2.bitwise_and(mask_final,cv2.bitwise_not(binary))
    cv2.imwrite(img_name+'_mask.jpg',mask_final)
    foregnd=cv2.bitwise_and(img,img,mask=mask_final)
    cv2.imwrite(img_name+'_foregnd.jpg',foregnd)
    return mask_final
##################################################
# OTSU Algorithm for all channels ends here
##################################################

##################################################
# OTSU Algorithm to find binary image starts here
##################################################

def algorithm_otsu(img,foregnd):
    # initialize number of pixels, total average intensity, histogram
    mu_temp=float(0)
    pixel=0
    histogram=np.zeros(256)
    # Initialize Cumulative probability, Mean of ith intensity pixel 
    w_i=0
    mu_i=0
    # Initialize threshold and variance between foreground and background
    k=-1
    max_Sig_B=-1
    # initialize a binary mask
    binary=np.zeros_like(img)
    # Obtain Histogram based on foreground
    for loop1 in range(img.shape[0]):
        for loop2 in range(img.shape[1]):
            if foregnd is None or foregnd[loop1][loop2] !=0:
                pixel+=1
                mu_temp+=img[loop1,loop2]
                histogram[img[loop1,loop2]]+=1
    # total average intensity is given below
    mu_t=mu_temp/pixel
    
    # Compute max sigma b^2 and the corresponding threshold
    for loop in range(256):
        # n_i of each gray level is:
        n_i= histogram[loop]
        p_i= float(n_i)/pixel
        # finding W_i and mu_i for each gray level
        w_i+=p_i
        mu_i+= loop*p_i
        # Ignore the infinity conditions
        if w_i ==0 or (1-w_i)==0:
            continue
        # Find variance between classes
        sig_B_i=(mu_t*w_i-mu_i)**2/(w_i*(1-w_i))        
        # update the threshold if necessary
        if sig_B_i >  max_Sig_B:
            k=loop
            max_Sig_B=sig_B_i
    # if there is no difference between foreground and background
    if k == -1:
        # send a blank binary output
        return binary
    # Create a binary image
    for loop1 in range(img.shape[0]):
        for loop2 in range(img.shape[1]):
            if img[loop1,loop2]> k:
                binary[loop1,loop2]= 255
    return binary
##################################################
# OTSU Algorithm to find binary image starts here
##################################################

###################################
# Extracting texture from the image 
###################################
def texture_img(image):
    # create an empty base image
    texture=np.zeros_like(image)
    # get the gray scale image
    gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
    # Creating the window size
    W_Size=np.array([3,5,7])
    for loop in range(len(W_Size)):
        dim=W_Size[loop]/2
        for r in xrange(dim,gray.shape[0]-dim):
            for c in xrange(dim,gray.shape[1]-dim):
                texture[r][c][loop]=int(np.var(gray[r-dim:r+1+dim,c-dim:c+1+dim]))
        
    return texture