%% Cascaded AdaBoost algorithm input function
% Author: Vishveswaran Jothi
function [idx]=CascadeAda(features,cntP,cntN,idxprev,stage)
cntN=length(idxprev)-cntP;
Ntot=length(idxprev);
% considering feature used till previous iteration
feat=features(:,idxprev);
% initialize the weights
wt=zeros(Ntot,1);
% initialize the label names
name=zeros(Ntot,1);
% set the name as 1 for the features of positive samples
for loop=1:Ntot
    if loop <=cntP
        wt(loop)=0.5/cntP;
        name(loop)=1;
    else
        wt(loop)=0.5/cntN;
    end
end

%AdaBoost Process
% iteration (T) is 40
T=40;
% initialize alpha,h(t),result of strong classifier and result of h
stg_cls=zeros(Ntot,1);
alpha=zeros(T,1);
% 4 different values are stored in ht they are
% error, polarity, feature index, theta.
ht=zeros(4,T); 
hR=zeros(Ntot,T);
Acc_P=zeros(T,1);
Acc_N=zeros(T,1);
for iter=1:T
   % normalize
   wt=wt./sum(wt); 
   % obtain the best weak classifier and the detection error
   [err,polarity,fidx,theta,bR]=getWeakcls(feat,wt,name,cntP);
   ht(1,iter)=err;
   ht(2,iter)=polarity;
   ht(3,iter)=fidx;
   ht(4,iter)=theta;
   hR(:,iter)=bR;
   % obtain the trust factor usin gthe trust factor formula
   alpha(iter)=log((1-err)/err);
   % update the weight as per the result from the weak classifier
   wt=wt.*(err/(1-err)).^(1-xor(name,bR));
   % select the strong classifier from the set of weak classifiers
   stg_clstemp=hR(:,1:iter)*alpha(1:iter,:);
   % determine threshold as
   thres=min(stg_clstemp(1:cntP));
   
   for loop =1:Ntot
       if(stg_clstemp(loop)>=thres)
           stg_cls(loop)=1;
       else
           stg_cls(loop)=0;
       end
   end
   
   % Obtaining the accuracy for positive samples
   Acc_P(iter)=sum(stg_cls(1:cntP))/cntP;
   % Obtaining the accuracy for negative samples
   Acc_N(iter)=sum(stg_cls(cntP+1:end))/cntN;
   if (Acc_P(iter)==0.99 && Acc_N(iter) <= 0.05)
       break;
   end
end
% updating variables for the next iteration of the classifier
% find the no. of false positives
% for that first get the features of the images which are classified
% wrongly
[sortdN,idxN]=sort(stg_cls(cntP+1:Ntot));
% sorting the feature
for loop =1:cntN
    if sortdN(loop)>0
        idxN=idxN(loop:end);
        break;
    end
end

% sample index for the next iteration
idx =[1:cntP,cntP+idxN'];

% saving data since it may fill up more memory space w.r.to each stage for
% future analysis
name=strcat(num2str(stage),'.mat');
save(name,'stg_cls','Acc_N','ht','alpha','idx','thres','-mat','-v7.3');

end