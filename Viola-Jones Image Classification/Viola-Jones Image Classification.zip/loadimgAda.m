%% Function to load images
% Author: Vishveswaran Jothi
function [imgP,cntP,imgN,cntN] = loadimgAda(filepath,ext)

filesp=dir(strcat(filepath,'/positive/',ext));
filesn=dir(strcat(filepath,'/negative/',ext));
[im1dummyr,im1dummyc,~]=size(imread(strcat(filepath,'/positive/',filesp(1).name)));
[im2dummyr,im2dummyc,~]=size(imread(strcat(filepath,'/negative/',filesn(1).name)));
% count of positive and negative images are also passed
cntP=length(filesp);
cntN=length(filesn);
imgP=zeros(im1dummyr,im1dummyc,cntP);
imgN=zeros(im2dummyr,im2dummyc,cntN);
% yP=zeros(length(filesp),1);
% yN=zeros(length(filesn),1);
parfor loop=1:cntP 
          img1=rgb2gray(imread(strcat(filepath,'/positive/',filesp(loop).name)));
          imgP(:,:,loop)=img1;
          
end
parfor loop=1:cntN
          img1=rgb2gray(imread(strcat(filepath,'/negative/',filesn(loop).name)));
          imgN(:,:,loop)=img1;
          
end
% yP(:)=1;
% yN(:)=-1;
end