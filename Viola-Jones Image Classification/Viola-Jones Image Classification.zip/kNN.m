%% k-NN algorithm
function y_predict=kNN(x_training,y_training,x_testdata,k,param)
% finding euclidean distance
% initializing base values
[row_train,col_train]=size(x_training);
[row_test,col_test]=size(x_testdata);
y_predict=zeros(row_test,1);
% check for the parameter
if(param =='euclidean') 
for outloop =1:row_test
    
    % reducing a iteration by using repmat
    % finding euclidean distance
    x_testdata_rep=repmat(x_testdata(outloop,:),[row_train,1]);
    diff=x_training-x_testdata_rep;
    euc_sq=sum((diff.^2),2);    
    euc=(euc_sq.^(0.5));
    % finding k nearest neighbours
    y_tmp=[];
    for n=1:k
       [data,idx]=min(euc);
       y_tmp=[y_tmp;y_training(idx)];
       euc(idx)=nan;
    end
    % finding the count of y_training that match with nearest neighbours
    count_match=unique(y_training);
    cnt_class=zeros(length(count_match),1);
    % outer loop loops all the values of the prediction while inner loop
    % compares with each class of training set.
    for cnt_loop=1:length(y_tmp)
        for cnt_match=1:length(count_match)
            if(count_match(cnt_match)==y_tmp(cnt_loop))
                cnt_class(cnt_match)=cnt_class(cnt_match)+1;
            end    
        end
    end
    % Obtaining the maximum support from neighbours
    [val,class]=max(cnt_class);
    %storing the predicted value
    y_predict(outloop)=class;
end
else
    fprintf('Other than Euclidean are currently unavailable so please pass the parameter as euclidean..'); 
end
end