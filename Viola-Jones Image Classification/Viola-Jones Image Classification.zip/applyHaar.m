%% Extracting features from the Integral Images
% Author: Vishveswaran Jothi
function [Haarop]=applyHaar(II,fcnt)
Haarop=zeros(fcnt,1);

% Extracting horizontal features
% initialize the index
idx=1;
% In the first step reduce the width by half and keep the height as height
% of the image
%[-1 | 1]
for ht=1:size(II,1)
    for wd=1:size(II,2)/2
        for r=1:21-ht
            for c=1:41-2*wd
                % choosing the eight points in the integral image to apply
                % the haar filter
                r1=[r,c,ht,wd];
                r2=[r,c+wd,ht,wd];
                % applying different Haar filter sizes to the image
                % horizontally
                Haarop(idx)=sumII(II,r2)-sumII(II,r1);
                idx=idx+1;
            end
        end
    end
end
%[1 | -1]'
% Now height is reduced by half while the width is fully used
% Extracting vertical features
for ht=1:size(II,1)/2
    for wd=1:size(II,2)
        for r=1:21-2*ht
            for c=1:41-wd
                 % choosing the eight points in the integral image to apply
                % the haar filter
                r1=[r,c,ht,wd];
                r2=[r+ht,c,ht,wd];
                Haarop(idx)=sumII(II,r1)-sumII(II,r2);
                idx=idx+1;
            end
        end
    end
end
end