%% Obtain the best weak clasifier for the AdaBoost training dataset
% Author: Vishveswaran Jothi
function [err,polarity,fidx,theta,bR]=getWeakcls(feat,wt,name,cntP)
% initialize the parameters
Nf=size(feat,1);
img_cnt=size(feat,2);
err=Inf;

tP=repmat(sum(wt(1:cntP,1)),img_cnt,1);
tN=repmat(sum(wt(cntP+1:img_cnt,1)),img_cnt,1);

% consider each feature as a potential weak classifier 
for loop=1:Nf
   % Obtain 1 feature per image
   F=feat(loop,:);
   res=zeros(img_cnt,1);
   % sort the feature according to the feature value for each image
   [sortF,sortidx]=sort(F,'ascend');
   % Now sort weights and labels accordingly
   sortwt=wt(sortidx);
   sortname=name(sortidx);
   % Obtaining the positive and negative error
   pos_sum=cumsum(sortwt.*sortname);
   % negative are the ones with their names as zeros hence remove the
   % positive weight from total wt will give negative weight
   neg_sum=cumsum(sortwt)-pos_sum;
   errP=pos_sum+(tN-neg_sum);
   errN=neg_sum+(tP-pos_sum);
   % finding minimum error in positive and negative sample classification
   errminPN=min(errP,errN);
   [errmin,idxmin]=min(errminPN);
   
   % Apply the minimum error to get the best result
   if errP(idxmin)<=errN(idxmin)
       p_temp=-1;
       res(idxmin+1:end)=1;
       res(sortidx)=res;
   else
       p_temp=1;
       res(1:idxmin)=1;
       res(sortidx)=res;
   end
   % compare with the best parameters from the previous iteration and
   % retain the best among them
   if(errmin<err)
       err=errmin;
       if idxmin==1
           theta=sortF(1)-0.5; % changed from 0.5
       elseif idxmin==Nf
           theta=sortF(Nf)+0.5; % changed from 0.5
       else
           theta=(sortF(idxmin)+sortF(idxmin-1))/2;
       end
       polarity=p_temp;
       fidx=loop;
       bR=res;
   end
end
% return only the retained best values in the weak classifier search
end
