%% Function to compute the feature vector of LDA
function [W]=LDAfeature()

gm=mean(img_unroll,2);
gm_mat=repmat(gm,1,max(y_train));
cmean=zeros(size(img_unroll,1),max(y_train));
% Computing the scatter for within class (GGT) we are obtaining G such that
% it can be used for the computation trick
Xi_mean=zeros(size(img_unroll));

Sw_GT=zeros(size(img_unroll,1),21);
for loop=1:max(y_train)
    cmean(:,loop)=mean(img_unroll(:,(loop-1)*21+1:loop*21),2);
    % Finding the mean of the training data
    Xi_mean(:,(loop-1)*21+1:loop*21)=img_unroll(:,(loop-1)*21+1:loop*21)-repmat(cmean(:,loop),1,21);
    % Finding the mean of the test data
    %Xtest_mean(:,(loop-1)*21+1:loop*21)=img_testN(:,(loop-1)*21+1:loop*21)-repmat(cmean(:,loop),1,21);
    %Sw_GT=Sw_GT+Xi_mean(:,(loop-1)*21+1:loop*21);
end
% Between class mean
BCmean=cmean-gm_mat;
% Using the computation trick
Sb=(BCmean'*BCmean);
% obtaining the right eigen vector
[Y,Db]=eig(Sb);
Db_diag=diag(Db);
% [~,index]=sort(-1*Db_diag);
% Y=Y(:,index);
% To get left eigen vector
Y=(BCmean*Y);
idx=[];
for loop =1:length(Db)
   if(Db_diag(loop)>=threshold)
      idx=[idx,loop]; 
   end
end
Ynew=Y(:,idx);

% obtaining Db as described in tutorial
Dbnew1=Y'*BCmean*BCmean'*Y;

Z=Ynew*(Dbnew1(idx,idx)^(-0.5));
% Now the Scatter of within class is given by since GGT has every value
% divided by total no.of images G or GT will have the square root of it.
%Sw_GTZ=Z'*Sw_GT;
Sw_GTZ=Z'*Xi_mean;
% Find right eigen vector
Sw_Z=(Sw_GTZ*Sw_GTZ');
[U,Dw]=eig(Sw_Z);

% Finally getting the feature vector space in which all image will be
% projected
%U_fin=Sw_GTZ*U;

Ut_fin=U;
Wt=(Z*Ut_fin)';
Wt=normr(Wt);
end