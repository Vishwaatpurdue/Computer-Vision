%% Main program for part2 of Homework 11
% Author: Vishveswaran Jothi
clear; close all; clc;

%% Input and Initialization section for the Face Recognition using PCA

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Getting input from the user
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%path_prompt='Enter the path of the training folder:';
%k_prompt='Enter the no. features you need to classify the images(max = 200)';
%numC_prompt='Enter the no. of classification for the multi class problem';
%ext_prompt='Enter the extension as (*.jpg) format:';
%Stages_prompt='Enter the no.of stages:';
%path_test_prompt='Enter the path of the testing folder:';
%path=input(path_prompt);
%ext=input(ext_prompt);
%path_test=input(path_test_prompt);
%Stages=input(stages_prompt);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sample data provided for reference
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
path_train='/home/vishwa/661/HW11/HW11Pics/ECE661_2016_hw11_DB2/train';
path_test='/home/vishwa/661/HW11/HW11Pics/ECE661_2016_hw11_DB2/test';
ext='*.png';
Stages=20;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Main algorithm starts here
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Loading images and finding integral images
fprintf('Loading Images....\n');
fprintf('Computing Features from Integral Images ....\n');
% Loading one image to get the image dimension and setting the an array 
% for all images in a set  
%Initializing the parameters for image and classification class

[features_train,cnt_trP,cnt_trN]=getFeatures(path_train,ext);
[features_test,cnt_teP,cnt_teN]=getFeatures(path_test,ext);

%% Training the AdaBoost Algorithm

Stages=20;
idx=1:cnt_trP+cnt_trN;
features=features_train;
for loop =1:Stages
    idx=CascadeAda(features,cnt_trP,cnt_trN,idx,loop);
    
    % stop the iteration if all negatives are detected correctly
    if (length(idx)==cnt_trN)
        break;
    end
end

%% Testing the trained Adaboost algorithm
Stages=20;
% Initializing the accuracy parameters
f_pos=zeros(Stages,1);
f_neg=zeros(Stages,1);
t_pos=zeros(Stages,1);
t_neg=zeros(Stages,1);
% Apply Adaboost for all test images stage wise

for loop=1:Stages
   % load mat files for each stage
   %name=strcat(num2str(loop),'.mat');
   %Sfile=load([num2str(loop) '.mat']);
   load([num2str(loop) '.mat']);
   % Now obtain the no.of weak classifier needed to build the strong
   % classifier
   t=0;
   for inloop=1:size(ht,2)
       if(ht(:,inloop)==0)
           break;
       else
           t=t+1;
       end
   end
   % obtain polarity for each stage from ht
   polarity=ht(2,1:t);
   % obtain selected features from the ht
   fidx=ht(3,1:t);
   % weak classifier threshold from ht
   theta=ht(4,1:t);
   % obatin alpha
   alpha=alpha(1:t,1);
   
   % classifying the test images w.r. to the built Adaboost classifier
   class=Classify_adaboost(features_test,alpha,polarity,theta,fidx,t);
   
   %Now computing the accuracy
   f_pos(loop)=sum(class(cnt_teP+1:end))/cnt_teN;
   f_neg(loop)=(cnt_teP-sum(class(1:cnt_teP)))/cnt_teP;
   t_pos(loop)=sum(class(1:cnt_teP))/cnt_teP;
   t_neg(loop)=(cnt_teN-sum(class(cnt_teP+1:end)))/cnt_teN;
   
end

% Plotting the results
plot_Adaboostresult(t_pos,t_neg,f_pos,f_neg);

