%% Main program for part1 of Homework 11
% Author: Vishveswaran Jothi
clear; close all; clc;

%% Input and Initialization section for the Face Recognition using PCA

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Getting input from the user
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%path_prompt='Enter the path of the training folder:';
%k_prompt='Enter the no. features you need to classify the images(max = 200)';
%numC_prompt='Enter the no. of classification for the multi class problem';
%ext_prompt='Enter the extension as (*.jpg) format:';
%path_test_prompt='Enter the path of the testing folder:';
%path=input(path_prompt);
%k=input(k_prompt);
%ext=input(ext_prompt);
%path_test=input(path_test_prompt);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sample data provided for reference
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

path='/home/vishwa/661/HW11/HW11Pics/ECE661_2016_hw11_DB1/train';
k=15;
ext='*.png';
path_test='/home/vishwa/661/HW11/HW11Pics/ECE661_2016_hw11_DB1/test';
accPCA=[];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Main algorithm starts here
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
files=dir(strcat(path,'/',ext));
files_test=dir(strcat(path_test,'/',ext));
fprintf('Few Assumptions on the input are Input images are of same sizes.');
fprintf('\nImage/File name consist of the classification name/type....\n');
% Assumption that all training and test images are of same size(height and width)
fprintf('Assumption that all training and test images are of same size(height and width) \n');
fprintf('Loading Images....\n');
% Loading one image to get the image dimension and set the unroll vector dimension accordingly. 
% Initializing the parameters for image and classification class
imdummy=imread(strcat(path,'/',files(1).name));
img_unroll=zeros(size(imdummy,1)*size(imdummy,2),length(files));
img_test=zeros(size(imdummy,1)*size(imdummy,2),length(files_test));
y_train=zeros(length(files),1);
y_org=zeros(length(files_test),1);
if length(files_test)==length(files)
   parfor loop=1:length(files) 
          img=rgb2gray(imread(strcat(path,'/',files(loop).name)));
          img1=rgb2gray(imread(strcat(path_test,'/',files_test(loop).name)));
          img_unroll(:,loop)=reshape(img,size(imdummy,1)*size(imdummy,2),1);
          img_test(:,loop)=reshape(img1,size(imdummy,1)*size(imdummy,2),1);
          y_train(loop)=str2num(strtok(files(loop).name,'_'));
          y_org(loop)=str2num(strtok(files_test(loop).name,'_'));
   end
else
    for loop=1:length(files) 
          img=imread(strcat(path,'/',files(loop).name));
          img_unroll(:,loop)=reshape(img,size(img_unroll,1),1);
    end
    for loop=1:length(files_test) 
          img1=imread(strcat(path_test,'/',files_test(loop).name));
          img_test(:,loop)=reshape(img1,size(img_test,1),1);
    end
end



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PCA Algorithm
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% the opt is the option required for my normalization function 
% It normalizes a matrix with respect to each row, col, or the complete
% matrix

img_unrollN=normc(img_unroll);
% compute the m vector which is the mean of the x vector
m=mean(img_unrollN,2);
% Compute the X vector
m_mat=repmat(m,1,size(img_unroll,2));
% subtracting with the mean to get the X vector
X=img_unrollN-m_mat;

Wtot=PCA_alg(X,k);
Wtot=normc(Wtot);

% Normalize the test data
img_testN=normc(img_test);
% compute the m vector which is the mean of the x vector
mtest=mean(img_testN,2);
mtest_mat=repmat(m,1,size(img_test,2));
% subtracting with the mean to get the X vector for test images
Xtest=img_testN-mtest_mat;

% Apply the training data and test data for varying feature space as per
% user input
for iter =1:k
W=Wtot(:,1:iter);
fprintf('Training the dataset....\n');
f_vec=W'*X;
% Now testing with the given images set
f_test=W'*Xtest;
y_predict=NN(f_vec',y_train',f_test','euclidean');
% Finding the accuracy of the Nearest Neighbor Algorithm
fprintf('Data Evaluated.....\n');
diff=y_org-y_predict;
matches=0;
for i=1:length(diff)
    if(diff(i)==0)
        matches=matches+1;
    end
end
accuracy=matches*100/length(diff);
fprintf('Accuracy of the NN based on the %d feature extraction is %f %...\n',iter,accuracy);
accPCA=[accPCA;accuracy];
end

%% Using LDA
% threshold is assumed to be 1e-5 to remove eigen value closer to zero
threshold=0.01;
gm=mean(img_unroll,2);
gm_mat=repmat(gm,1,max(y_train));
cmean=zeros(size(img_unroll,1),max(y_train));
% Computing the scatter for within class (GGT) we are obtaining G such that
% it can be used for the computation trick
Xi_mean=zeros(size(img_unroll));

Sw_GT=zeros(size(img_unroll,1),21);
for loop=1:max(y_train)
    cmean(:,loop)=mean(img_unroll(:,(loop-1)*21+1:loop*21),2);
    % Finding the mean of the training data
    Xi_mean(:,(loop-1)*21+1:loop*21)=img_unroll(:,(loop-1)*21+1:loop*21)-repmat(cmean(:,loop),1,21);
    % Finding the mean of the test data
    %Xtest_mean(:,(loop-1)*21+1:loop*21)=img_testN(:,(loop-1)*21+1:loop*21)-repmat(cmean(:,loop),1,21);
    %Sw_GT=Sw_GT+Xi_mean(:,(loop-1)*21+1:loop*21);
end
% Between class mean
BCmean=cmean-gm_mat;
% Using the computation trick
Sb=(BCmean'*BCmean);
% obtaining the right eigen vector
[Y,Db]=eig(Sb);
Db_diag=diag(Db);
% [~,index]=sort(-1*Db_diag);
% Y=Y(:,index);
% To get left eigen vector
Y=(BCmean*Y);
idx=[];
for loop =1:length(Db)
   if(Db_diag(loop)>=threshold)
      idx=[idx,loop]; 
   end
end
Ynew=Y(:,idx);

% obtaining Db as described in tutorial
Dbnew1=Y'*BCmean*BCmean'*Y;

Z=Ynew*(Dbnew1(idx,idx)^(-0.5));
% Now the Scatter of within class is given by since GGT has every value
% divided by total no.of images G or GT will have the square root of it.
%Sw_GTZ=Z'*Sw_GT;
Sw_GTZ=Z'*Xi_mean;
% Find right eigen vector
Sw_Z=(Sw_GTZ*Sw_GTZ');
[U,Dw]=eig(Sw_Z);

% Finally getting the feature vector space in which all image will be
% projected
%U_fin=Sw_GTZ*U;

Ut_fin=U;
Wt=(Z*Ut_fin)';
Wt=normr(Wt);
%% Train and testing the given image dataset
accLDA=zeros(k,1);
% generating a mean matrix for training dataset and testing data set
mean_m=repmat(gm,1,length(y_train));
meantest_m=repmat(mean(img_test,2),1,length(y_org));
Xtrain=img_unroll-mean_m;
Xtest_mean=img_test-meantest_m;
for loop=1:k
   W_apply=Wt(1:loop,:);

   x_trainfeature=W_apply*Xtrain;
   x_testfeature=W_apply*Xtest_mean;
   % Using NN function to compute the best match for the given test data
   y_predict=NN(x_trainfeature',y_train',x_testfeature','euclidean');
   % Finding progressive accuracy of inclusion of each feature until it
   % reaches the user defined no.of features 
   % Finding the accuracy of the Nearest Neighbor Algorithm
   fprintf('Data Evaluated.....\n');
   diff=y_org-y_predict;
   matches=0;
   for i=1:length(diff)
   if(diff(i)==0)
       matches=matches+1;
   end
   end
   accuracy=matches*100/length(diff);
   fprintf('Accuracy of the NN based on the %d feature extraction by LDA is %f %...\n',loop,accuracy);
   accLDA(loop)=accuracy;
end
%% Plotting the accuracy Vs no. of feature space
figure;
hold on;
cnt=[];
% Ploting the accuracy points
for loop=1:k
    cnt=[cnt;loop];
    plot(loop,accPCA(loop),'dr','MarkerSize',4,'MarkerFaceColor','r');
    plot(loop,accLDA(loop),'*r','MarkerSize',4);
end
plot(cnt,accPCA,'-b','linewidth',2);
fig=plot(cnt,accLDA,'-g','linewidth',2);
xlabel('No.of Features choosen in feature space to discriminate input');
ylabel('Accuracy obtained for progressive feature inclusion');
title('PLot for PCA and LDA');
legend('PCA','LDA');
hold off;
saveas(fig,'Plot of PCA & LDA','jpg');

