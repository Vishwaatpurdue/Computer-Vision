%% Function to give Integral images output with Haar filters
% Author: Vishveswaran Jothi
function [features,cntP,cntN]=getFeatures(path,ext)
% Loading the data can be training or testing
[im_p,cntP,im_n,cntN]=loadimgAda(path,ext);
% findin gno. of images
Ntot=cntP+cntN;
% Assumption the positive and neagtive images are of same dimension also
% all images are of same dimension
[rcnt,ccnt]=size(im_p(:,:,1));
% Nf (feature count)used from previous report
Nf=166000;
features=zeros(Nf,Ntot);
parfor loop =1:cntP
    % initilaize integral images
    II=zeros(rcnt+1,ccnt+1);
    % since cumsum is cumulative sum that adds up the previous and current
    % value both row and col wise, it is used to get integral images
    % computing it manually will take a long computational time hence a 
    %function is not built
    II(2:end,2:end)=cumsum(cumsum(im_p(:,:,loop)),2);
    features(:,loop)=applyHaar(II,Nf);
end
parfor loop=cntP+1:Ntot
    % initilaize integral images
    II=zeros(rcnt+1,ccnt+1);
    % since cumsum is cumulative sum that adds up the previous and current
    % value both row and col wise, it is used to get integral images
    % computing it manually will take a long computational time hence a 
    %function is not built
    II(2:end,2:end)=cumsum(cumsum(im_n(:,:,loop-cntP)),2);
    features(:,loop)=applyHaar(II,Nf);
end
% saving the feature extraction according to the input
pathname=strsplit(path,'/');
name=strcat('features_Adaboost_',pathname{end},'.mat');
save(name,'features','cntP','cntN','-mat','-v7.3');
end