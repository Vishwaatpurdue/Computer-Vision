%% User interface section
clc; clear; close all;
% path_train_prompt='Enter the file path to load the training images';
% path_test_prompt='Enter the file path to load the test images';
% k_prompt='Enter the feture limit to choose for LDA based image classification';
% ext_prompt='Enter the file format of the image files';
% 
% path_train=input(path_train_prompt);
% path_test=input(path_test_prompt);
% k=input(k_prompt);
% ext=input(ext_prompt);


%% Function to implement the LDA for image classification
path_train='C:\Me\Masters\ECE 661\HW11\HW11Pics\ECE661_2016_hw11_DB1\train';
path_test='C:\Me\Masters\ECE 661\HW11\HW11Pics\ECE661_2016_hw11_DB1\test';
k=15;
ext='png';
% threshold is assumed to be 1e-5 to remove eigen value closer to zero
threshold=1e-5;
files_train=dir(strcat(path_train,'/*.',ext)); 
files_test=dir(strcat(path_test,'/*.',ext)); 
% Assumption that all training and test images are of same size(height and width)
fprintf('Assumption that all training and test images are of same size(height and width) \n');
% Loading one image to get the image dimension and set the unroll vector dimension accordingly. 
% Initializing the parameters for image and classification class
imdummy=imread(strcat(path_train,'/',files_train(1).name));
imunroll=zeros(size(imdummy,1)*size(imdummy,2),length(files_train));
img_test=zeros(size(imdummy,1)*size(imdummy,2),length(files_test));
y_train=zeros(length(files_train),1);
y_org=zeros(length(files_test),1);
if length(files_test)==length(files_train)
   parfor loop=1:length(files_train) 
          img=rgb2gray(imread(strcat(path_train,'/',files_train(loop).name)));
          img1=rgb2gray(imread(strcat(path_test,'/',files_test(loop).name)));
          imtrain(:,loop)=reshape(img,size(imdummy,1)*size(imdummy,2),1);
          imtest(:,loop)=reshape(img1,size(imdummy,1)*size(imdummy,2),1);
          y_train(loop)=str2num(strtok(files_train(loop).name,'_'));
          y_org(loop)=str2num(strtok(files_test(loop).name,'_'));
   end
else
    for loop=1:length(files_train) 
          img=imread(strcat(path_train,'\',files_train(loop).name));
          imtrain(:,loop)=reshape(img,size(imtrain,1),1);
    end
    for loop=1:length(files_test) 
          img1=imread(strcat(path_test,'\',files_test(loop).name));
          imtest(:,loop)=reshape(img1,size(imtest,1),1);
    end
end
% Normalizing the training and testing dataset
imtrainN=normc(imtrain);
imtestN=normc(imtest);
%% FInding global and local mean(mean of each class) for the given data set
gm=mean(imtrainN,2);
gm_mat=repmat(gm,1,max(y_train));
cmean=zeros(size(imtrain,1),max(y_train));
% Computing the scatter for within class (GGT) we are obtaining G such that
% it can be used for the computation trick
Xi_mean=zeros(size(imtrain));
Xtest_mean=zeros(size(imtest));
Sw_GT=zeros(size(imtrain,1),21);
for loop=1:max(y_train)
    cmean(:,loop)=mean(imtrainN(:,(loop-1)*21+1:loop*21),2);
    % Finding the mean of the training data
    Xi_mean(:,(loop-1)*21+1:loop*21)=imtrainN(:,(loop-1)*21+1:loop*21)-repmat(cmean(:,loop),1,21);
    % Finding the mean of the test data
    Xtest_mean(:,(loop-1)*21+1:loop*21)=imtestN(:,(loop-1)*21+1:loop*21)-repmat(cmean(:,loop),1,21);
    Sw_GT=Sw_GT+Xi_mean(:,(loop-1)*21+1:loop*21);
end
% Between class mean
BCmean=cmean-gm_mat;
% Using the computation trick
Sb=(BCmean'*BCmean)./max(y_train);
% obtaining the right eigen vector
[Y,Db]=eig(Sb);
Db_diag=diag(Db);
% To get left eigen vector
Y=BCmean*Y;
idx=[];
for loop =1:length(Db)
   if(Db_diag(loop)>=threshold)
      idx=[idx,loop]; 
   end
end
Ynew=Y(:,idx);
Dbnew=Db(idx,idx);
Z=Ynew*(Dbnew.^0.5);
% Now the Scatter of within class is given by since GGT has every value
% divided by total no.of images G or GT will have the square root of it.
Sw_GT=Sw_GT./sqrt(max(y_train)*21);
Sw_GTZ=Sw_GT'*Z;
% Find right eigen vector
Sw_Z=Sw_GTZ'*Sw_GTZ;
[U,Dw]=eig(Sw_Z);
Ut=Sw_GTZ*U;
Dw_diag=diag(Dw);
%% finding Uhat w.r. to k (no. of feature vectors needed)

indx=[];
for loop=1:length(Dw_diag)
    if(min(Dw_diag)<= threshold)
        [~,temp]=min(Dw_diag);
    indx=[indx,temp];
    % removing the min idx every time from the Dw since it will create 
    Dw_diag(temp)=10*max(Dw_diag);
    end
end
Ut_fin=Ut(:,indx);
% Finally getting the feature vector space in which all image will be
% projected

%% Train and testing the given image dataset
accLDA=zeros(1,k);
iter=[];
for loop=1:k
   iter=[iter;loop];
   Wt=Ut_fin*Z';
   W_apply=Wt(1:loop,:);
   x_trainfeature=W_apply*Xi_mean;
   x_testfeature=W_apply*Xtest_mean;
   % Using NN function to compute the best match for the given test data
   y_predict=NN(x_testfeature,x_trainfeature,y_train');
   % Finding progressive accuracy of inclusion of each feature until it
   % reaches the user defined no.of features 
   plot(loop,accuracy,'*r','MarkerSize',3);
   hold on;
end
xlabel('No.of Features choosen in feature space to discriminate input');
ylabel('Accuracy obtained for progressive feature inclusion');
title('PLot for PCA and LDA');
legend('PCA','LDA');
fig=plot(iter,accLDA,'-b','linewidth',2);
hold off;
saveas(fig,'Plot of LDA','jpg');


