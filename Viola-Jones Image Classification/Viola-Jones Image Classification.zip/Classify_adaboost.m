%% Function for AdaBoost classifier
% Author: Vishveswaran Jothi
function [class] = Classify_adaboost(features,alpha,polarity,theta,fidx,T)
% get the total no.of images
cntImg=size(features,2);
% initialize the classification
classini=zeros(cntImg,T);

% classify using the weak classifier selected from the list of features
for loop=1:T
    feat=features(fidx(loop),:);
    for inloop=1:cntImg
       if polarity(loop)*feat(inloop)<=polarity(loop)*theta(loop)
       classini(inloop,loop)= 1;
       end
    end
end   
% Now combining weak classifiers to get strong classifier
stg_cls=classini*alpha(1:T,:);
% generating the threshold for the classifier
thres=0.5*sum(alpha(1:T,1));
%initialize the final classification output
class=zeros(cntImg,1);  
for loop=1:cntImg
    if stg_cls(loop)>=thres
       class(loop)=1; 
    end
end
end