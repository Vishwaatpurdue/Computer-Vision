%% Function to find the cumulative product of each accuracy component
function [t_acc]=cumcomp(t)
Stages=length(t);
for stage=1:Stages
   t_rate=t(1:stage);
   for loop=2:stage
       if t_rate(loop)==0
           t_rate(loop)=t_rate(loop-1);
           break;
       end
   end
   t_acc=cumprod(t_rate);
end