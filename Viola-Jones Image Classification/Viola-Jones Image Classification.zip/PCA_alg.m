%% Function to get Feature matrix using PCA (W_matrix)
% Author: Vishveswaran Jothi
function [W]=PCA_alg(X,k)
W=[];
% compute Cprime say the pseudo C matrix for easy computation of eigen
% vectors
Cp=(X'*X)/630;
% Note SVD is not used if svd has to be used then there is no point in 
% computing the matrix multiplication of Cp, we can do C itself.
[V,D]=eig(Cp);
D=diag(D);
[~,idx]=sort(-1.*D);
V=V(:,idx);
Wtemp=X*V;
% cross check with svd
[~,~,V1]=svd(X);
Wtmp1=X*V1(:,1:k);
% Now extracting the K vectors which are having maximum eigen values

W=Wtemp;
end