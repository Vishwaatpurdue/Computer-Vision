%% NN algorithm
% Author: Vishveswaran Jothi
function y_predict=NN(x_training,y_training,x_testdata,param)
% finding euclidean distance
% initializing base values
[row_train,col_train]=size(x_training);
[row_test,col_test]=size(x_testdata);
%y_predict=zeros(row_test,1);
% check for the parameter
if(param =='euclidean')
    y_tmp=[];
for outloop =1:row_test
    % reducing a iteration by using repmat
    % finding euclidean distance
    x_testdata_rep=repmat(x_testdata(outloop,:),[row_train,1]);
    diff=x_training-x_testdata_rep;
    euc_sq=sum((diff.^2),2);    
    euc=sqrt(euc_sq);
    [data,idx]=min(euc);
    y_tmp=[y_tmp;y_training(idx)];
end
else
    fprintf('Other than Euclidean are currently unavailable so please pass the parameter as euclidean..'); 
end
y_predict=y_tmp;
end
    