%% plotting function for AdaBoost Classifier
function [] =plot_Adaboostresult(t_pos,t_neg,f_pos,f_neg)
Stages=length(t_pos);
% initilialize the cummulative values
% tp_rate=zeros(Stages,1);
% tn_rate=tp_cum;
% finding cumulative true positive
tp_cum=cumcomp(t_pos);
tn_cum=cumcomp(t_neg);
fp_cum=cumcomp(f_pos);
fn_cum=1-tp_cum;
stage=1:Stages;
figure;
hold on;
plot(stage',fp_cum,'-b','linewidth',3);
plot(stage',fn_cum,'-r','linewidth',3);
for loop=1:Stages
   plot(loop,fp_cum(loop),'*r','markerSize',5); 
   fig=plot(loop,fn_cum(loop),'db','markerSize',5);
end
xlabel('No.of.Stages');
ylabel('Accuracy');
legend('False Positives','False negatives');
hold off;
save(fig,'plot1','jpg');
end