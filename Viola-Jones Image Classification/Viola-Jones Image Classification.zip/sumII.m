%% Function to apply the sum of the intensities
% Author: Vishveswaran Jothi
function[op]=sumII(II,bound)
r_st=bound(1);
c_st=bound(2);
ht=bound(3);
wd=bound(4);
% Finding A,B,C,D to compute the sum of the region between them 
A = II(r_st,c_st);
B = II(r_st,c_st+wd);
C = II(r_st+ht,c_st);
D = II(r_st+ht,c_st+wd);
% Computing sum of the region covered rectangle ABCD
op=D+A-(B+C);
end