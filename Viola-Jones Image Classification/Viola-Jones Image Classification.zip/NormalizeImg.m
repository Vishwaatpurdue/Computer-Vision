%% Function to normalize the given matrix with respect to each row,
%column
% Author: Vishveswaran Jothi
function Mat_norm=NormalizeImg(Mat,opt)

if(opt==2)
    % Normalize w.r. to columns
    fprintf('\n Normalizing w.r.to columns... \n');
    Mat_norm=normc(Mat);
    
else
    % Normalize w.r. to rows
    fprintf('\n Normalizing w.r.to rows... \n');
    Mat_norm=normr(Mat);
    
end
end
