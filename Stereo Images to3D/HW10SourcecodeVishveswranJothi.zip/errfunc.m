%% Generating error function to optimise F using LM algorithm
function error=errfunc(p,points1,points2)
%Pp=[p(1),p(4),p(7),p(10);];
Pp=reshape(p(1:12),3,4);
%Pp(3,4)=1;
%ep=null(f');
P=[eye(3),[0;0;0]];
% To get the X world from the parameter vector (p)
cnt=13;
X=[];
for loop=1:((length(p)-12)/3)
X=[X,p(cnt:cnt+2)];
cnt=cnt+3;
end
points1=[points1';ones(1,length(points1))];
points2=[points2';ones(1,length(points2))];
X=[X;ones(1,length(X))];
points1_proj=P*X;
points2_proj=Pp*X;
points1_proj=[points1_proj(1,:)./points1_proj(3,:);points1_proj(2,:)./points1_proj(3,:);points1_proj(3,:)./points1_proj(3,:);];
points2_proj=[points2_proj(1,:)./points2_proj(3,:);points2_proj(2,:)./points2_proj(3,:);points2_proj(3,:)./points2_proj(3,:);];
dif=(points1-points1_proj).^2;
sum_dif1=dif(1,:)+dif(2,:)+dif(3,:);
dif2=(points2-points2_proj).^2;
sum_dif2=dif2(1,:)+dif2(2,:)+dif2(3,:);
error=sum(sum_dif1(:))+sum(sum_dif2(:));
end