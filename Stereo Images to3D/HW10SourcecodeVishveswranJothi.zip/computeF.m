%% Function to Compute F matrix
function F_init=computeF(points1,points2,T1,T2)
row=length(points1);
points1=points1';
points2=points2';
% generate the A matrix to compute Af=0
Mat=[];
for i=1:row
Mat=[Mat;points2(i,1)*points1(i,1), points2(i,1)*points1(i,2), points2(i,1),...
    points2(i,2)*points1(i,1), points2(i,2)*points1(i,2), points2(i,2),...
    points1(i,1),points1(i,2),1];
end
% use svd to find the right eigen vector to find F matrix
[U,D,V]=svd(Mat);
Fvec=V(:,end);
% since it reshapes column wise
F=reshape(Fvec,3,3);
F=F';
% Now condition the F matrix
[U1,D1,V1]=svd(F);
D1(end,end)=0;
F=U1*D1*V1';
F_init= T2'*F*T1;
end