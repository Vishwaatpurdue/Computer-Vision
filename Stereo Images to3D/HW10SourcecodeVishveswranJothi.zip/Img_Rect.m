%% Rectification of images using Hartley and Zisserman algorithm
function [imrect1,imrect2,F_rect,pts1,pts2,H1,H2]=Img_Rect(pts_1,pts_2,img1,img2,F)
[ht,wid,~]=size(img1);
count=length(pts_1);
% points are in column wise after the below steps
pts_H1=[pts_1';ones(1,length(pts_1))];
pts_H2=[pts_2';ones(1,length(pts_2))];
e=null(F);
ep=null(F');
P=[eye(3),[0;0;0]];
epx=[0,-ep(3),ep(2);ep(3),0,-ep(1);-ep(2),ep(1),0];
Pp=[epx*F,ep];
% making epipolar prime (ep) into the form (x,y,1)
ep=ep/ep(3);
e=e/e(3);
ang=atan(-(ep(2)-ht/2)/(ep(1)-wid/2));
f=cos(ang)*(ep(1)-wid/2)-sin(ang)*(ep(2)-ht/2);
R=[cos(ang),-sin(ang),0;sin(ang),cos(ang),0; 0,0,1];
T=[1,0,-wid/2;0,1,-ht/2;0,0,1];
G=[1,0,0;0,1,0;-1/f,0,1];
H2=G*R*T;

% keeping the center point in the image as constant
c_pt=[wid/2;ht/2;1];
c_pt_new=H2*c_pt;
c_pt_new=c_pt_new/c_pt_new(3);
T2=[1,0,wid/2-c_pt_new(1);0,1,ht/2-c_pt_new(2);0,0,1];
H2=T2*H2;


% For H1
ang=atan(-(e(2)-ht/2)/(e(1)-wid/2));
f=cos(ang)*(e(1)-wid/2)-sin(ang)*(e(2)-ht/2);
R=[cos(ang),-sin(ang),0;sin(ang),cos(ang),0; 0,0,1];
T=[1,0,-wid/2;0,1,-ht/2;0,0,1];
G=[1,0,0;0,1,0;-1/f,0,1];
H1=G*R*T;

% keeping the center point in the image as constant
c_pt=[wid/2;ht/2;1];
c_pt_new=H1*c_pt;
c_pt_new=c_pt_new/c_pt_new(3);
T1=[1,0,wid/2-c_pt_new(1);0,1,ht/2-c_pt_new(2);0,0,1];
H1=T1*H1;

% % Finding Homography for the first image by finding min a,b,c
% M=Pp*pinv(P);
% rank(M);
% if(rank(M)==2)
% %M=[Pp(:,1),Pp(:,3:4)];
% end
% H0=H2*M;
% 
% pts1_cap=ones(size(pts_H1));
% pts2_cap=ones(size(pts_H2));
% pts1_cap=H0*pts1_cap;
% pts2_cap=H2*pts2_cap;
% pts1_cap=[pts1_cap(1,:)./pts1_cap(3,:);pts1_cap(2,:)./pts1_cap(3,:);pts1_cap(3,:)./pts1_cap(3,:)];
% pts2_cap=[pts2_cap(1,:)./pts2_cap(3,:);pts2_cap(2,:)./pts2_cap(3,:);pts2_cap(3,:)./pts2_cap(3,:)];
% 
% % Find Ha matrix to get a,b,c values using Linear Least squares
% abc=pinv(pts1_cap')*(pts2_cap(1,:))';
% Ha=[abc(1),abc(2),abc(3);0,1,0;0,0,1];
% H1=Ha*H0;
% 
% % To preserve the center after applying homography
% c_pt=[wid/2;ht/2;1];
% c_pt_new=H1*c_pt;
% c_pt_new=c_pt_new/c_pt_new(3);
% T1=[1,0,wid/2-c_pt_new(1);0,1,ht/2-c_pt_new(2);0,0,1];
% H1=T1*H1;

% apply the homography to the fundamental matrix and the image coordinates
% such that the epipolar lines go to infinity along x axis
[imrect1, H1]=HomographyRect(H1,img1);
[imrect2, H2]=HomographyRect(H2,img2);
F_rect=inv(H2')*F*inv(H1);

% The coordinate points on the new plane is given by
pts1=zeros(size(pts_1,2),size(pts_1,1));
pts2=zeros(size(pts_2,2),size(pts_2,1));
tmp_pts1=H1*pts_H1;
tmp_pts2=H2*pts_H2;
pts1=[tmp_pts1(1,:)./tmp_pts1(3,:);tmp_pts1(2,:)./tmp_pts1(3,:)];
pts2=[tmp_pts2(1,:)./tmp_pts2(3,:);tmp_pts2(2,:)./tmp_pts2(3,:)];
end