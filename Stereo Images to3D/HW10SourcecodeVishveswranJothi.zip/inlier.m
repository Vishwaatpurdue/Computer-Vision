% Function to remove the outliers
function [pts1,pts2]=inlier(F_init,points_img1,points_img2,t);
pts1=[];
pts2=[];
points_img1=[points_img1,ones(length(points_img1),1)];
points_img2=[points_img2,ones(length(points_img2),1)];

% if the X2'Fx1< threshold then they pass else they fail
for loop=1:length(points_img1)
    if (points_img2(loop,:)*F_init*(points_img1(loop,:))'<=t)
        pts1=[pts1;points_img1(loop,1:2)];
        pts2=[pts2;points_img2(loop,1:2)];
    end
end
end