% Function to implement canny edge detector
function [eg]=cannyedge(Im)

img=rgb2gray(Im);
eg=edge(img,'canny',0.3);
figure;
imshow(eg);
end