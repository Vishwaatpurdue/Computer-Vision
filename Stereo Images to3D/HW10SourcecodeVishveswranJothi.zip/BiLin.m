%% Function to implement bilinear interpolation
function[pixel_val]=BiLin(temp_coords,img)
tp_lt=img(floor(temp_coords(2)),floor(temp_coords(1)),:);
tp_rt=img(floor(temp_coords(2)),floor(temp_coords(1))+1,:);
bt_lt=img(floor(temp_coords(2))+1,floor(temp_coords(1)),:);
bt_rt=img(floor(temp_coords(2))+1,floor(temp_coords(1))+1,:);
del_u=temp_coords(2)-floor(temp_coords(2));
del_v=temp_coords(1)-floor(temp_coords(1));
pixel_val=(1-del_u)*(1-del_v)*tp_lt+(1-del_v)*del_u*tp_rt...
    +(1-del_u)*del_v*bt_lt+del_u*del_v*bt_rt;
end