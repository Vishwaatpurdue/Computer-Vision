%% Main Program
close all; clear;
% Input from the user
%path_prompt='Enter the path where the image pair is located:';
%ext_prompt='Enter the extension of the image pair:';
%path=input(path_prompt);
%ext=input(ext_prompt);
path='/home/vishwa/661/HW10/HW10Pics/';
ext='*.jpg';
%ext='*.png';
dest_path='/home/vishwa/661/HW10/HW10Sourcecode/';
t=0.001;
%% Load the manually taken corresponding points on both images and estimate
% F matrix, the (x,y) are in vector form

% % house
% points_img1=[54,20;37,90;60,158.3;137,226;193,131.65;209,79;174,44;145.65,127];
% points_img2=[40.65,36.3;46.35,94.65;72,157;123.65,223.65;208,132.65;223,72.65;182,38.65;104.65,127.3];

% Book
% points_img1=[147,236;246,132;118,207.35;113.35,231.65;30.65,115;14.35,79;60.65,51;241.75,171.75];
% points_img2=[140.35,235.65;245.35,133;112,205.35;113.35,230;28.35,113;14.65,78.35;60.65,46.35;245,170.65];

% My image 2 - cardboard-1
% points_img1=[318.7,160.65;317.35,282.65;396.7,355.35;414.7,231.35;506.7,296.47;526,180;427.35,122.65;413.35,188];
% points_img2=[280,178.25;282,300;394,360;412,240.55;471.4,277.7;490.85,164;367.4,115.4;392,193.15];

% % My image 3 - cardboard-1
% points_img1=[541.35,320.7;571,667.5;891.35,932.75;920.65,596.55;1196.55,684.5;1310.35,324.15;925.85,120.7;882.75,267.25];
% points_img2=[575.85,263.8;601.7,641.4;770.65,965.5;772.4,586.2;1220.65,818.95;1337.9,424.15;1051.7,167.25;924.1,284.5];

% My image 4 - Box
points_img1=[451.7,279.3;482.75,700;798.25,987.95;843.1,529.3;1139.65,753.45;1244.8,337.95;850,150;951.7,305.2];
points_img2=[486.2,201.6;520.65,619;758.6,922.4;789.7,469;1165.5,730;1272.4,307;922.4,98.3;974.1,257];


g_ssd=5;
T_ssd=0.6;
surf_ip=1;
% Loading the images
files=dir(strcat(path,ext));

for loop=1:length(files)
img{loop}=imread(strcat(path,files(loop).name));

end

% Plot the imput images
name='points_coord.jpg';
plot2Dpoints(img{1},img{2},points_img1,points_img2,dest_path,name);

%% Initial estimation of F
% Now normalize the input points 
[pointn_1,T1]=NormalizedH(points_img1);
[pointn_2,T2]=NormalizedH(points_img2);
% Estimating initial F
F_init=computeF(pointn_1,pointn_2,T1,T2);

% Remove the outlier
[points_img1,points_img2]=inlier(F_init,points_img1,points_img2,t);
% finetuning F w.r. to P' since P has 11 DOF (12 but we set the last one to unity) 
% while F has 7 DOF but has 9 elements in it, we optimize w.r.to P matrix 
% thus it does not generate a wrong result.
%[P2,F_est,X1]=nlsqF(points_img1,points_img2,F_init);
% e=null(F_est)
% ep=null(F_est')
F_est=F_init;
% Rectify the images using the optimized F matrix
[imrect1,imrect2,F,pts1,pts2,H1,H2]=Img_Rect(points_img1,points_img2,img{1},img{2},F_est);


%% Using Surf interest point detector find Interest points and descriptors
% Also use canny edge detector to find the interest points - Bonus part
%Img1_gray=rgb2gray(imrect1);
%Img2_gray=rgb2gray(imrect2);
if (surf_ip==1)
    [points1,points2]=findCorres(imrect1,imrect2,T_ssd,g_ssd);
end

figure;
imshow([imrect1 imrect2]); hold on;
points1=[points1(2:end,:);pts1'];
points2=[points2(2:end,:);pts2'];

for loop=1: length(points1)
    points=[points1(loop,:);points2(loop,:)+[size(imrect1,2),0]];
    plot(points1(loop,1),points1(loop,2),'yo','MarkerSize',3,'MarkerFaceColor','y');
    fig2=plot(points2(loop,1)+size(imrect1,2),points2(loop,2),'yo','MarkerSize',3,'MarkerFaceColor','y');
    fig2=plot(points(:,1),points(:,2),'-r','linewidth',2);
end

hold off;
name='surf_points2.jpg';
%saveas(fig2,strcat(dest_path,name));
close all;



% % Finding and optimizing F for new points found using SURF 
[pointn_1,T1]=NormalizedH(points1);
[pointn_2,T2]=NormalizedH(points2);
% Estimating initial F
F_init=computeF(pointn_1,pointn_2,T1,T2);
[points1,points2]=inlier(F_init,points1,points2,t);
epi=null(F_init');
epxi=[0,-epi(3),epi(2);epi(3),0,-epi(1);-epi(2),epi(1),0];
P2=[epxi*F_init,epi];
% finetuning F w.r. to P' since P has 11 DOF (12 but we set the last one to unity) 
% while F has 7 DOF but has 9 elements in it, we optimize w.r.to P matrix 
% thus it does not generate a wrong result.
% F_init=F;
% epi=null(F_init');
% epxi=[0,-epi(3),epi(2);epi(3),0,-epi(1);-epi(2),epi(1),0];
% P2=[epxi*F_init,epi];

[P2,F_est,X]=nlsqF(points1,points2,F_init);
P2=P2; %./P2(end,end);
X=triang(points1,points2,P2);
X=X(:,2:end);

% Finally plotting the 3D world points
fname='3Dfinal.jpg';
plot3Dpoints(X,dest_path,fname);

%% Using Canny edge detector
[points1,points2]=findCannycorres(imrect1,imrect2,T_ssd,g_ssd);
figure;
imshow([imrect1 imrect2]); hold on;
points1=[points1(2:end,:);pts1'];
points2=[points2(2:end,:);pts2'];
for loop=1: length(points1)
    points=[points1(loop,:);points2(loop,:)+[size(imrect1,2),0]];
    plot(points1(loop,1),points1(loop,2),'yo','MarkerSize',3,'MarkerFaceColor','y');
    fig2=plot(points2(loop,1)+size(imrect1,2),points2(loop,2),'yo','MarkerSize',3,'MarkerFaceColor','y');
    fig2=plot(points(:,1),points(:,2),'-r','linewidth',2);
end

hold off;
name='canny1.jpg';
saveas(fig2,strcat(dest_path,name));
close all;


% Finding and optimizing F for new points found using SURF 
[pointn_1,T1]=NormalizedH(points1);
[pointn_2,T2]=NormalizedH(points2);
% Estimating initial F
F_init=computeF(pointn_1,pointn_2,T1,T2);
[points1,points2]=inlier(F_init,points1,points2,t);
epi=null(F_init');
epxi=[0,-epi(3),epi(2);epi(3),0,-epi(1);-epi(2),epi(1),0];
P2=[epxi*F_init,epi];
% finetuning F w.r. to P' since P has 11 DOF (12 but we set the last one to unity) 
% while F has 7 DOF but has 9 elements in it, we optimize w.r.to P matrix 
% thus it does not generate a wrong result.
% F_init=F;
% epi=null(F_init');
% epxi=[0,-epi(3),epi(2);epi(3),0,-epi(1);-epi(2),epi(1),0];
% P2=[epxi*F_init,epi];

[P2,F_est,X]=nlsqF(points1,points2,F_init);
P2=P2; %./P2(end,end);
X=triang(points1,points2,P2);
%X=X(:,2:end);

% Finally plotting the 3D world points
fname='3Dfinalcanny.jpg';
plot3Dpoints(X,dest_path,fname);


%%