%% Function for plotting the 3D world points
function []=plot3Dpoints(X,dest_path,fname)
figure;
X=X';
hold on;
scatter3(X(:,1),X(:,2),X(:,3),'ob','Linewidth',2); 
cnt=length(X)-7;
pt_line=X(cnt:end,:);

 for loop=1:3
plot3([pt_line(loop,1);pt_line(loop+1,1)],[pt_line(loop,2);pt_line(loop+1,2)],[pt_line(loop,3);pt_line(loop+1,3)],'-r','linewidth',2);
 end
plot3([pt_line(1,1);pt_line(4,1)],[pt_line(1,2);pt_line(4,2)],[pt_line(1,3);pt_line(4,3)],'-r','linewidth',2);
plot3([pt_line(3,1);pt_line(5,1)],[pt_line(3,2);pt_line(5,2)],[pt_line(3,3);pt_line(5,3)],'-r','linewidth',2);
plot3([pt_line(6,1);pt_line(5,1)],[pt_line(6,2);pt_line(5,2)],[pt_line(6,3);pt_line(5,3)],'-r','linewidth',2);
plot3([pt_line(6,1);pt_line(7,1)],[pt_line(6,2);pt_line(7,2)],[pt_line(6,3);pt_line(7,3)],'-r','linewidth',2);
plot3([pt_line(6,1);pt_line(4,1)],[pt_line(6,2);pt_line(4,2)],[pt_line(6,3);pt_line(4,3)],'-r','linewidth',2);
plot3([pt_line(1,1);pt_line(7,1)],[pt_line(1,2);pt_line(7,2)],[pt_line(1,3);pt_line(7,3)],'-r','linewidth',2);
% fig=plot3([pt_line(1,1);pt_line(7,1)],[pt_line(1,2);pt_line(7,2)],[pt_line(1,3);pt_line(7,3)],'-r','linewidth',2);
hold off;
saveas(fig,strcat(dest_path,fname));

end