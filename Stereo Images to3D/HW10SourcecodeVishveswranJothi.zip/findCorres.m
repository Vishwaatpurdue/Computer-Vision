%% Finding correspondence for the given images
function [points1,points2]=findCorres(imrect1,imrect2,thresh1,thresh2)

if(length(imrect1(1,1,:))>1)
Img1_gray=rgb2gray(imrect1);
Img2_gray=rgb2gray(imrect2);
else
% Img1_gray=imrect1;
% Img2_gray=imrect2;
end
pts1 = detectSURFFeatures(Img1_gray,'MetricThreshold', 2000);
pts2 = detectSURFFeatures(Img2_gray,'MetricThreshold', 2000);


% pts1 = pts1.selectStrongest(250);
% pts2 = pts2.selectStrongest(250);

[features1,validpoints1]=extractFeatures(Img1_gray,pts1);
[features2,validpoints2]=extractFeatures(Img2_gray,pts2);
idxpt=matchFeatures(features1,features2);
matchedPoints1 = validpoints1(idxpt(:,1),:);
matchedPoints2 = validpoints2(idxpt(:,2),:);
points1=matchedPoints1.Location;
points2=matchedPoints2.Location;
% features1=features1(idxpt(:,1),:);
% features2=features2(idxpt(:,2),:);
% % Finding matches using SSD
% points1=matchedPoints1.Location;
% points2=matchedPoints2.Location;
%[points1,points2,id]=SSD(validpoints1.Location,validpoints2.Location,features1,features2,thresh1,thresh2);
% [points1,points2,id]=SSD(validpoints1,validpoints2,features1,features2,thresh1,thresh2);
end