% Function for finding SSD
function [points1,points2,id]=SSD(validpoints1,validpoints2,features1,features2,lt,gt)
points1=[];
points2=[];
points1f=[];
points2f=[];
SSD_mat=zeros(length(validpoints1),length(validpoints2));
for oloop=1:length(validpoints1)
    for iloop=1:length(validpoints2)

        SSD_mat(oloop,iloop)=sum((features1(oloop,:)-features2(iloop,:)).^2);
    end
end
% Finding global mean
g_mean=mean(SSD_mat(:));
for oloop=1:length(validpoints1)
    % Finding minimum value of that row
   min1=min(SSD_mat(oloop,:));
   % check with global threshold if it passes look for local threshold
   if (min1<=gt*g_mean)
      [~,idx]=min(SSD_mat(oloop,:));
      SSD_mat(oloop,idx)=25000;
      min2=min(SSD_mat(oloop,:));
      if (min1/min2 < lt)
          points1=[points1;validpoints1(oloop,:)];
          points2=[points2;validpoints2(idx,:)];
          SSD_mat(:,idx)=25000*g_mean;
      end
   else
       continue;
   end
end
% Finding if matches are within limits
id=[];

for loop=1:length(points1)
    if(points1(loop,2)-points2(loop,2)<=25)
        id=[id;loop];
        points1f=[points1f;points1(loop,:)];
        points2f=[points2f;points2(loop,:)];
    end
end
end