%% Plot 2D points on image
function []= plot2Dpoints(img1,img2,points1,points2,dest_path,name)
[height,width,~]=size(img1);
% concatenating both the images
img=[img1 img2];

imshow(img);
hold on;
points2_c=points2+repmat([width,0],length(points2),1);

for loop=1:length(points2)
points=[points1(loop,1),points1(loop,2);points2_c(loop,1),points2_c(loop,2)];
fig=plot(points(:,1),points(:,2),'r-','linewidth',1);
fig=plot(points1(loop,1),points1(loop,2),'yo','MarkerSize',3,'MarkerFaceColor','y');
fig=plot(points2_c(loop,1),points2_c(loop,2),'yo','MarkerSize',3,'MarkerFaceColor','y');
end
hold off;
saveas(fig,strcat(dest_path,name));
close all;

end