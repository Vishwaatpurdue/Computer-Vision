%% Code for to get new homography and apply it to rectify the image
function[imrect, H_n]=HomographyRect(H,img)
img=single(img);
[ht,wid,~]=size(img);

% boundaries of the image
b_pts=[1,1;size(img,2),1;1,size(img,1);size(img,2),size(img,1)];

% New boundary points for the new image plane
b_pts_new=H*[b_pts';ones(1,4)];
b_pts_new=[b_pts_new(1,:)./b_pts_new(3,:);b_pts_new(2,:)./b_pts_new(3,:);b_pts_new(3,:)./b_pts_new(3,:)];
% Finding the minimum in (x,y) coordinates
min_val=min(b_pts_new');
max_val=max(b_pts_new');
Dim=(max_val-min_val)';
Dim=[floor(Dim(1));floor(Dim(2))];
H_scaling=[wid/Dim(1),0,0;0,ht/Dim(2),0;0,0,1];
H=H_scaling*H;
% For translation
b_pts_new=H*[b_pts';ones(1,4)];
b_pts_new=[b_pts_new(1,:)./b_pts_new(3,:);b_pts_new(2,:)./b_pts_new(3,:);b_pts_new(3,:)./b_pts_new(3,:)];
% Finding the minimum in (x,y) coordinates
min_val=min(b_pts_new');
%max_val=max(b_pts_new');
Dim=min_val';
Dim=[floor(Dim(1));floor(Dim(2))];
% generate the offset values
T=[1,0,-Dim(1)+1;0,1,-Dim(2)+1;0,0,1];
% Apply offsets to the Homography function
H_n=T*H;
Hinv=inv(H_n);
% generate base image
Base=zeros(size(img));
for outloop=1:ht
    for inloop=1:wid
        temp_coords=Hinv*[inloop;outloop;1];
        temp_coords=temp_coords(1:2)./temp_coords(3);
        if(temp_coords(1)>1 && temp_coords(2)>1 && temp_coords(1)<wid && temp_coords(2)<ht)
            Base(outloop,inloop,:)=BiLin(temp_coords,img);
        end
    end
end
imrect=uint8(Base);
end