% Function to get the descriptor
function [points,descriptor]=findDescriptor(point,img,W)
% swapping the x,y coordinates to row,col coordinates for ease of
% computation
temp=[point(:,2),point(:,1)];
point=temp;
points=[];
% initializing descriptor
descriptor=zeros(length(point),(W+1)^2);
w=W/2;
for loop=1:length(point)
    if(point(loop,1)-w>1 || point(loop,1)+w<size(img,1)...
            ||point(loop,2)-w>1 || point(loop,2)+w<size(img,2))
    tmp=img(point(loop,1)-w:point(loop,1)+w,point(loop,2)-w:point(loop,2)+w);
    descriptor(loop,:)=(tmp(:))';
    points=[points;[point(loop,2),point(loop,1)]];
    end
end

end