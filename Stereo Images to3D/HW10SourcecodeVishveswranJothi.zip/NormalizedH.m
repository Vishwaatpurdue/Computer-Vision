%% Function to find the normalized matrix and to normalize the points using it
function [points_norm, T]=NormalizedH(points)
% points are arranged as per rows
points=points';
mean_x=mean(points(1,:));
mean_y=mean(points(2,:));
% finding the distance between mean and the points
temp=[mean_x;mean_y];
mean_mat=repmat(temp,1,length(points));
dist_temp=(points-mean_mat).^2;
dist=(dist_temp(1,:)+dist_temp(2,:)).^0.5;
mean_dist=sum(dist)/length(points);
% Setting mean distance as sqrt(2)
scale=(2^0.5)/mean_dist;
% The below x, y makes zero mean for the points
x=-scale*mean_x;
y=-scale*mean_y;
% finally the Transformation matrix is given by
T=[scale, 0,x;0,scale,y;0,0,1];
points_norm=T*[points;ones(1,size(points,2))];
end