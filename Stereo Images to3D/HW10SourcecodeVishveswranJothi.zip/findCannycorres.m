%% Function to implement canny edge detector

function[points1,points2]=findCannycorres(imrect1,imrect2,T_ssd,g_ssd)
% Initializing the points
point1=[];
point2=[];
% Finding the edge of theimage
edg_1 = cannyedge(imrect1);
edg_2 = cannyedge(imrect2);
size(edg_1)
for i=100:706
    for j=270:964
        if(edg_1(i,j)==1)
            point1=[point1;[j,i]];
        end
    end
end
for i=147:633
    for j=332:901
        if(edg_2(i,j)==1)
            point2=[point2;[j,i]];
        end
    end
end
% set the window size to 24
W=10;
% choosing 5000 points randomly
idx1 = randperm(length(point1),2000);
idx2 = randperm(length(point2),2000);
point1=point1(idx1,:);
point2=point2(idx2,:);
% finding descriptor to each image
im1_g=rgb2gray(imrect1);
im2_g=rgb2gray(imrect2);
 [point1,descriptor1]=findDescriptor(point1,im1_g,W);
 [point2,descriptor2]=findDescriptor(point2,im2_g,W);
% [features1,valid_points1] = extractFeatures(im1_g,point1);
% [features2,valid_points2] = extractFeatures(im2_g,point2);
% indexPairs = matchFeatures(features1,features2);
% points1=valid_points1(indexPairs(:,1),:);
% points2=valid_points2(indexPairs(:,2),:);

% Using SSD to find the best feature match
%[points1,points2,~]=SSD(point1,point2,descriptor1,descriptor2,T_ssd,g_ssd);
[points1,points2,~]=NCC(point1,point2,descriptor1,descriptor2,T_ssd,g_ssd);

%[points1,points2,~]=NCC(valid_points1,valid_points2,features1,features2,T_ssd,g_ssd);
end
