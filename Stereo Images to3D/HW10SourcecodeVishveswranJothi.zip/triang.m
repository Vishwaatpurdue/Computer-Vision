% Function for triangulation
function[X]=triang(points1,points2,P2)
P=[eye(3),[0;0;0]];
Pp=P2;
X=[];
for i=1:size(points1,1)
   A=[points1(i,1)*P(3,:)-P(1,:);points1(i,2)*P(3,:)-P(2,:);...
       points2(i,1)*Pp(3,:)-Pp(1,:);points2(i,2)*Pp(3,:)-Pp(2,:)]; 
   [U,D,V]=svd(A);
   X=[X,V(:,end)/V(end,end)];
end
end