%% Finding optimized F using Lm optimization
function[P2,F_est,X]=nlsqF(points1,points2,F)
%points1=points1';
%points2=points2';
% initializing the parameter vector
points1=double(points1);
points2=double(points2);
p=zeros(12+length(points1)*3,1);
% Finding the initial e' using estimated F. 
epi=null(F');
ep=null(F);
% Finding [e']x
epxi=[0,-epi(3),epi(2);epi(3),0,-epi(1);-epi(2),epi(1),0];
% Finding initial P' to pass into the error function to optimize the
% parameter vector
P=[eye(3),[0;0;0]];
Pp=[epxi*F,epi];
%Pp=Pp./Pp(end,end);
X=[];
for i=1:size(points1,1)
   A=[points1(i,1)*P(3,:)-P(1,:);points1(i,2)*P(3,:)-P(2,:);...
       points2(i,1)*Pp(3,:)-Pp(1,:);points2(i,2)*Pp(3,:)-Pp(2,:)]; 
   [U,D,V]=svd(A);
   X=[X,V(:,end)/V(end,end)];
end
p(1:12)=reshape(Pp,12,1);
X_vec=reshape(X(1:3,:),length(points1)*3,1);
p(13:end)=X_vec;
error=errfunc(p,points1,points2);
options=optimoptions('lsqnonlin','Algorithm','levenberg-marquardt','MaxIter',10000);
p_new=lsqnonlin(@errfunc,p,[],[],options,points1,points2);
error1=errfunc(p_new,points1,points2);
Pp=reshape(p_new(1:12),3,4);
%Pp=Pp./Pp(end,end);
ep=Pp(:,4);
epx=[0,-ep(3),ep(2);ep(3),0,-ep(1);-ep(2),ep(1),0];
F_est=epx*Pp(:,1:3);
P2=Pp;
% To get the X world optimized
cnt=13;
X=[];
for loop=1:(length(p_new)-12)/3
X=[X;p_new(cnt:cnt+2)'];
cnt=cnt+3;
end
X=X';
end